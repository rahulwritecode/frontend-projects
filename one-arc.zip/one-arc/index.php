<?php



$keyword = $_REQUEST['cstm_ppc_keyword'];
$channel = $_REQUEST['cstm_ppc_channel'];
$campaign = $_REQUEST['cstm_ppc_campaign'];
$placement = $_REQUEST['cstm_ppc_placement'];
$device = $_REQUEST['cstm_ppc_device'];
$SRD = $_REQUEST['SRD'];


if (isset($keyword)) {
    setcookie('cstm_ppc_keyword', $keyword, time() + (86400 * 180));
}
if (isset($channel)) {
    setcookie('cstm_ppc_channel', $channel, time() + (86400 * 180));
}
if (isset($campaign)) {
    setcookie('cstm_ppc_campaign', $campaign, time() + (86400 * 180));
}
if (isset($placement)) {
    setcookie('cstm_ppc_placement', $placement, time() + (86400 * 180));
}
if (isset($device)) {
    setcookie('cstm_ppc_device', $device, time() + (86400 * 180));
}
if (isset($SRD)) {
    setcookie('SRD', $SRD, time() + (86400 * 180));
}

// cloudfront Distribution----     https://d33vmb1l2jev57.cloudfront.net
// PROD
// for production, keep below two lines uncommented, and comment below line labeled LOCAL
// $assetVers = 0;
// $assetBase = 'https://d33vmb1l2jev57.cloudfront.net/assets-' . $assetVers . '/';

// LOCAL
// for local, keep below line uncommented, and comment above two lines.
$assetBase = '';


?>


<!doctype html>
<html lang="en">

<head>
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-TNMTFMKJ');
    </script>
    <!-- End Google Tag Manager -->


    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Sonam One Arc</title>
    <link rel="icon" href="<?php echo $assetBase; ?>images/favicon-logo.webp" type="image/png" sizes="16x16">
    <!-- Bootstrap CSS -->
    <!-- Latest compiled and minified bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo $assetBase; ?>css/plugin.min.css">

    <!--Menu css files-->
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/menu.css">
    <!--End Menu css files-->
    <link rel="stylesheet" href="<?php echo $assetBase; ?>css/style.css">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>css/responsive.css">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>css/fonts.css">

    <!-- owl carousal  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TNMTFMKJ" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->



    <!--NAVIGATION START-->
    <?php include 'menu.php' ?>
    <!--NAVIGATION END-->


    <div id="home-carousel" class="carousel slide carousel-fade" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#home-carousel" data-slide-to="0" class="active"></li>
            <li data-target="#home-carousel" data-slide-to="1" class=""></li>
            <li data-target="#home-carousel" data-slide-to="2" class=""></li>
        </ol>
        <div class="carousel-inner" role="listbox">


            <div class="item active">
                <!-- <img src="<?php echo $assetBase; ?>images/slider/Web-b.webp" alt="" class="slide zoom hidden-xs"> -->
                <!-- <video width="100%" class="hidden-xs" autoplay="" loop="" muted="">
                    <source src="images/videobanner.mp4" type="video/mp4">
                </video> -->

                <div class="desktop-video-banner">
                    <div style="padding:56.25% 0 0 0;position:relative;"><iframe src="https://player.vimeo.com/video/933181663?badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=58479&autoplay=1&loop=1&title=0&muted=1&autopause=false&transparent=0&controls=0&#t=2s" frameborder="0" allow="autoplay; fullscreen; picture-in-picture; clipboard-write" style="position:absolute;top:0;left:0;width:100%;height:100%;" title="videobanner"></iframe>
                    </div>
                    <script src="https://player.vimeo.com/api/player.js"></script>


                </div>


                <!-- <img src="<?php echo $assetBase; ?>images/slider/Mobile-b.webp" alt="" class="slide zoom visible-xs"> -->
                <!-- 
                <video width="100%" class="visible-xs" autoplay="" loop="" muted="" style="margin-top: 79px;">
                    <source src="images/mobile.mp4" type="video/mp4">
                </video> -->

                <div class="mobile-video-banner">
                    <div style="padding:177.78% 0 0 0;position:relative;"><iframe src="https://player.vimeo.com/video/933184660?badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=58479&autoplay=1&loop=1&title=0&muted=1&autopause=false&transparent=0&controls=0&#t=2s" frameborder="0" allow="autoplay; fullscreen; picture-in-picture; clipboard-write" style="position:absolute;top:0;left:0;width:100%;height:100%;" title="MOBILE_1"></iframe>
                    </div>
                    <script src="https://player.vimeo.com/api/player.js"></script>
                </div>


            </div>


        </div>
        <a class="left carousel-control" href="#home-carousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#home-carousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <section class="seprator">

    </section>


    <section class="cover-sec" id="Overview">
        <div class="row mr0">
            <div class="col-md-6 pd0 hidden-xs">
                <div class="cover-img">
                    <img src="<?php echo $assetBase; ?>images/ame/02.webp" class="img1Pos" alt="Sonam One Arc Luxury interior ">
                    <p class="imagepatch">Representative Image</p>
                </div>
            </div>
            <div class="col-md-6 pd0">
                <div class="cover-content">
                    <div>
                        <h2 id="h2title" class="cover-tittle" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                            <span>UNMATCHED. UNRIVALLED. ULTIMATE.</span><br>
                            THE ONE ABOVE ALL.
                        </h2>
                        <div style="width: 100%;height: 30px;"></div>
                        <p data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                            In the bustling landscape of residential projects, stands as a beacon of distinction,
                            unmatched by any other. Not merely as a mark of superiority, but as a testament to our
                            unwavering commitment to excellence. With unparalleled amenities, unrivalled craftsmanship,
                            and the ultimate in luxury living, transcends expectations to emerge as the definitive
                            choice for those who seek the epitome of refined living. From the grandeur of its
                            architecture to the meticulous attention to detail in every corner, THE ONE reigns supreme,
                            setting a new standard of excellence in residential living.
                        </p>
                        <div style="width: 100%;height: 30px;"></div>
                        <!-- <a href="#" data-type="iframe" data-src="#" title="" data-fancybox="view360" class="youtube"
                            data-aos="fade-up" data-aos-delay="600" data-aos-duration="1000">

                       
                            <span class="svgwrap">
                                <svg id="videoicon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 59.02 59.01">
                                    <path d="M254.58,271.36A29,29,0,1,0,270,279"
                                        transform="translate(-220.49 -270.49)" />
                                    <polyline points="25.01 40.78 43.01 29.51 20.01 16.23 20.01 42.78" />
                                </svg>
                            </span>
                            <span class="virtual-txt">360° Virtual Tour</span>
                        </a> -->
                    </div>
                </div>
            </div>
            <div class="col-md-6 pd0 visible-xs">
                <div class="cover-img">
                    <img src="<?php echo $assetBase; ?>images/ame/02.webp" alt="Sonam One Arc Luxury interior ">
                    <p class="imagepatch">Representative Image</p>
                </div>
            </div>
        </div>
    </section>

    <!-- <section class="full-imgsec scroll-wrap2 section-pad" id="ProjectsHighlight" style="background:#e2bb6c;">
        <div class="full-secoverlay ">
            <div>
                <h2 style="letter-spacing: 3px;" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                    PROJECT HIGHLIGHTS
                </h2>

                <div class="project-icon-wrap" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                    <div class="row">
                        <div class="col-md-4 col-6">
                            <div class="icon-wrap d-flex justify-content-center">
                                <img src="<?php echo $assetBase; ?>images/living.webp" class="highlight-icon"
                                    alt="Sonam One Arc luxury living room icon ">
                            </div>
                            <h3>Largest 3,4 & 5 Bed Residences</h3>
                        </div>
                        <div class="col-md-4 col-6">
                            <div class="icon-wrap d-flex justify-content-center">
                                <img src="<?php echo $assetBase; ?>images/height.webp" class="highlight-icon"
                                    alt="Sonam One Arc luxury room height icon">
                            </div>
                            <h3>11.98 Feet floor-to-ceiling height </h3>
                        </div>
                        <div class="col-md-4 col-12">
                            <div class="icon-wrap">
                                <img src="<?php echo $assetBase; ?>images/amenities.webp" class="highlight-icon"
                                    alt="Sonam One Arc luxury room amenities">
                            </div>
                            <h3>10+ Handpicked Amenities</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->



    <!-- <section class="full-imgsec scroll-wrap1" style="background-image: url('images/fullsec1.webp');">
        <div class="full-secoverlay item-center">
            <div>
                <h2 data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">GIVE IN TO THE SLIGHTEST WHIM</h2>
                <img class="rellax a-scroll" data-rellax-speed="2" src="<?php echo $assetBase; ?>images/A1.webp">
            </div>
        </div>
    </section> -->

    <section class="seprator"></section>

    <section class="cover-sec">
        <div class="row mr0">

            <div class="col-md-6 pd0">
                <div class="cover-content">
                    <div>
                        <h2 class="cover-tittle" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                            <span></span><br>
                            An Arc OF RARITY <br>
                            <span>REVERENCE AND RESPECT.
                            </span>
                        </h2>
                        <div style="width: 100%;height: 30px;"></div>
                        <p data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                            Step into the Arc of Rarity, where homes become more than addresses - they become
                            manifestations of prestige and exclusivity. This curated location, forming an elegant arc,
                            is a canvas for elite living. Embrace the subtle sophistication of residences strategically
                            placed to create an arc that symbolizes reverence and respect.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 pd0">
                <div class="cover-img">
                    <img src="<?php echo $assetBase; ?>images/ame/01.webp" alt="Sonam One Arc luxury room sky view ">
                    <p class="imagepatch">Representative Image</p>
                </div>
            </div>
        </div>
    </section>

    <section class="seprator"></section>

    <section class="cover-sec ">
        <div class="row mr0">
            <div class="col-md-6 pd0 hidden-xs">
                <div class="cover-img">
                    <img src="<?php echo $assetBase; ?>images/ame/03.webp">
                    <p class="imagepatch">Representative Image</p>
                </div>
            </div>
            <div class="col-md-6 pd0">
                <div class="cover-content">
                    <div>
                        <h2 class="cover-tittle" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                            <span>AN INSIGNIA THAT DRAWS THE </span><br>
                            LINE OF DISTINGUISHED LIVING

                        </h2>
                        <div style="width: 100%;height: 30px;"></div>
                        <p data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                            Experience an emblem that signifies the pinnacle of distinguished living, where opulence
                            meets bespoke luxury. Welcome to a signature enclave, artfully curated to synchronize with
                            your discerning preferences, presenting an existence of elegance amidst thoughtful comfort
                            and design.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 pd0 visible-xs">
                <div class="cover-img">
                    <img src="<?php echo $assetBase; ?>images/ame/03.webp">
                    <p class="imagepatch">Representative Image</p>
                </div>
            </div>
        </div>
    </section>



    <section class="seprator"></section>


    <section class="cover-sec">
        <div class="row mr0">

            <div class="col-md-6 pd0">
                <div class="cover-content">
                    <div>
                        <h2 class="cover-tittle" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                            <span>'MORE SPACE FOR YOUR </span><br>
                            CHIVALRY & CHARISMA
                        </h2>
                        <div style="width: 100%;height: 30px;"></div>
                        <p data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000"> Prepare to be captivated by
                            the sheer expanse of our living spaces, where indulgence meets magnificence. Bask in the
                            freedom of generous proportions, where every room is an invitation to luxuriate in comfort
                            and style. Experience the rare privilege of abundant legroom, where your chivalry and
                            charisma find ample space to shine.

                        </p>

                    </div>
                </div>
            </div>
            <div class="col-md-6 pd0 ">
                <div class="cover-img">
                    <img class="img2Pos src=" src="<?php echo $assetBase; ?>images/ame/04.webp" alt="Sonam One Arc luxury room interior">
                    <p class="imagepatch">Artist's Impression</p>
                </div>
            </div>
        </div>
    </section>


    <!-- <section class="cover-sec">
        <div class="row mr0">
            <div class="col-md-6 pd0">
                <div class="cover-img">
                    <img src="<?php echo $assetBase; ?>images/sec-img5.webp">
                    <p class="imagepatch">Shot On Location</p>
                </div>
            </div>
            <div class="col-md-6 pd0">
                <div class="cover-content">
                    <div>
                        <h2 class="cover-tittle" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                            <span>HOMES AT</span><br>
                            Sonam One Arc
                        </h2>
                        <h3 class="coversubhead" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                            CREATED FOR A COMMUNITY OF LIKE-MINDED PEOPLE.
                        </h3>
                        <div style="width: 100%;height: 30px;"></div>
                        <ul class="coverlist" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                            <li>
                                <div><img src="<?php echo $assetBase; ?>images/bullet.webp"></div>
                                Magnificent cityscape views
                            </li>
                            <li>
                                <div><img src="<?php echo $assetBase; ?>images/bullet.webp"></div>
                                Plush interiors
                            </li>
                            <li>
                                <div><img src="<?php echo $assetBase; ?>images/bullet.webp"></div>
                                Ample light and cross ventilation
                            </li>
                            <li>
                                <div><img src="<?php echo $assetBase; ?>images/bullet.webp"></div>
                                Complete privacy with no two apartments facing each other
                            </li>
                            <li>
                                <div><img src="<?php echo $assetBase; ?>images/bullet.webp"></div>
                                Separate service elevator
                            </li>
                            <li>
                                <div><img src="<?php echo $assetBase; ?>images/bullet.webp"></div>
                                Separate staff entrance
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section> -->


    <!-- <section class="full-imgsec scroll-wrap3" style="background-image: url('images/fullsec4.webp');">
        <div class="full-secoverlay item-center">
            <div>
                <h2 data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">GIVE IN TO EVERY INDULGENCE</h2>
                <img class="rellax3 a3-scroll" data-rellax-speed="2" src="<?php echo $assetBase; ?>images/A2.webp">
            </div>
        </div>
    </section> -->




    <!-- 
    <section style="background:#f3f3f3" class="section-pad" id="projectsHighlight">
        <div class="container">
            <div class="sec-tittle">
                <h2 style="color:#000; " data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                    PROJECT HIGHLIGHTS
                </h2>
                <div class="headline"></div>
            </div>
            <div class="row">
                <div class="col-md-4 col-12">
                    <div class="highlight-content-icon" data-aos="fade-up" data-aos-delay="300"
                        data-aos-duration="1000">
                        <div class="icon-wrap ">
                            <img src="<?php echo $assetBase; ?>images/living-room.webp" class="highlight-icon"
                                alt="Sonam One Arc luxury living room icon ">
                        </div>
                        <h3 class="highlight-icon-text text-black">Largest 3,4 & 5 Bed Residences</h3>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="highlight-content-icon" data-aos="fade-up" data-aos-delay="300"
                        data-aos-duration="1000">
                        <div class="icon-wrap d-flex justify-content-center">
                            <img src="<?php echo $assetBase; ?>images/height.webp" class="highlight-icon"
                                alt="Sonam One Arc luxury room height icon">
                        </div>
                        <h3 class="highlight-icon-text text-black">11.98 Feet floor-to-ceiling height </h3>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="highlight-content-icon" data-aos="fade-up" data-aos-delay="300"
                        data-aos-duration="1000">
                        <div class="icon-wrap">
                            <img src="<?php echo $assetBase; ?>images/amenities.webp" class="highlight-icon"
                                alt="Sonam One Arc luxury room amenities">
                        </div>
                        <h3 class="highlight-icon-text text-black">10+ Handpicked Amenities</h3>
                    </div>
                </div>
            </div>
        </div>
    </section> 
    -->

    <section class="configsec" id="configuration" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
        <div class="container">
            <div class="sec-tittle">
                <h2>Configuration</h2>
                <div class="headline"></div>
            </div>
            <div style="width: 100%;height: 10px;"></div>
            <!-- <table class="table config-table">
                <thead>
                    <tr>
                        <th> <b>Type</b> </th>
                        <th>Area SQ.FT</th>
                        <th> <b> Price</b> </th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td>3 BHK</td>
                        <td>1781 Sq. Ft</td>

                        <td>
                            <a href="javascript:void (0);" class="price-click">
                                Click Here
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td>4 BHK</td>
                        <td>2181 Sq. Ft</td>

                        <td>
                            <a href="javascript:void (0);" class="price-click">
                                Click Here
                            </a>
                        </td>
                    </tr>
                </tbody>
            </table> -->
            <div class="row justify-section-center">
                <div class="  col-md-4 col-12">
                    <div class="project-config-card">
                        <h3 class="config-head">
                            3 BHK
                        </h3>
                        <div class="config-line"></div>
                        <h2 class="config-area"> 1781 SQ.FT.<br></h2>
                        <!-- <button class="config-btn">₹ Check Price</button> -->
                        <a href="javascript:void (0);" class="config-btn price-click">
                            ₹ Check Price
                        </a>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="project-config-card">
                        <h3 class="config-head">
                            4 BHK
                        </h3>
                        <div class="config-line"></div>
                        <h2 class="config-area">2184 SQ.FT.<br></h2>
                        <a href="javascript:void (0);" class="config-btn price-click">
                            ₹ Check Price
                        </a>
                    </div>
                </div>

            </div>



            <p class="diclaimer-text">
                <b>Disclaimer: As per RERA Carpet Area</b>
            </p>
        </div>
    </section>

    <section class="project-highlight-section section-pad" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
        <div class="container">
            <div class="sec-tittle">
                <h2 class="text-white"> PROJECT HIGHLIGHTS</h2>
                <div class="headline"></div>
            </div>
            <div style="width: 100%;height: 10px;"></div>
            <div class="row">
                <div class="col-md-4 col-12  outer-border ">
                    <div class="highlight-section-wrap  ">
                        <div class="highlight-card  ">
                            <img src="images/ph1.webp" class="highlight-icon" alt="">
                        </div>
                        <h5 class="highlight-text text-align-center ">Largest 3,4 & 5 Bed Residences</h5>
                    </div>
                </div>
                <div class="col-md-4 col-12  outer-border ">
                    <div class="highlight-section-wrap  ">
                        <div class="highlight-card  ">
                            <img src="images/ph3.webp" class="highlight-icon" alt="">
                        </div>
                        <h5 class="highlight-text text-align-center ">11.98 Feet floor-to-floor height</h5>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="highlight-section-wrap  ">
                        <div class="highlight-card   ">
                            <img src="images/ame33.png" class="highlight-icon" alt="">
                        </div>
                        <h5 class="highlight-text text-align-center ">10+ Handpicked Amenities</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="" id="Amenities">
        <div class="row mr0">
            <!-- <div class="sec-tittle">
                <h2 class="text-white" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">AMENITIES</h2>
                <div class="headline"></div>
            </div> -->
        </div>
        <div class="owl-carousel owl-theme ami-carousel">
            <!-- -------------------->
            <div class="item">
                <div class="amenities-wrap">
                    <div class="row mr0">
                        <div class="col-md-6 pd0">
                            <div class="ami-imgwrap">
                                <img src="<?php echo $assetBase; ?>images/ame/ame1.webp">
                                <p class="imagepatch">Artist Impression</p>
                            </div>
                        </div>
                        <div class="col-md-6 pd0">
                            <div class="amenities-content">
                                <div style="width: 100%">
                                    <h2 class="cover-tittle">Play Zone</h2>
                                    <div class="ameline"></div>
                                    <div class="col-md-6">
                                        <ul class="coverlist amilist">
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Pool
                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Table Tennis
                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Indoor Games Room

                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Kids Play Area

                                            </li>

                                        </ul>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- -------------------->
            <div class="item">
                <div class="amenities-wrap">
                    <div class="row mr0">
                        <div class="col-md-6 pd0">
                            <div class="ami-imgwrap">
                                <img src="<?php echo $assetBase; ?>images/ame/ame3.webp">
                                <p class="imagepatch">Artist Impression</p>
                            </div>
                        </div>
                        <div class="col-md-6 pd0">
                            <div class="amenities-content">
                                <div style="width: 100%">
                                    <h2 class="cover-tittle">Fitness Zone</h2>
                                    <div class="ameline"></div>
                                    <div class="col-md-6">
                                        <ul class="coverlist amilist">
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Swimming Pool

                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Gym
                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Yoga Centre

                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Terrace Turf

                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Walkway
                                            </li>

                                        </ul>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- -------------------->
            <div class="item">
                <div class="amenities-wrap">
                    <div class="row mr0">
                        <div class="col-md-6 pd0">
                            <div class="ami-imgwrap">
                                <img src="<?php echo $assetBase; ?>images/ame/ame6.webp">
                                <p class="imagepatch">Artist Impression</p>
                            </div>
                        </div>
                        <div class="col-md-6 pd0">
                            <div class="amenities-content">
                                <div style="width: 100%">
                                    <h2 class="cover-tittle">Social Hubs</h2>
                                    <div class="ameline"></div>
                                    <div class="col-md-6">
                                        <ul class="coverlist amilist">
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Cafe
                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Multipurpose Hall
                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Library
                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Movie Theatre
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <ul class="coverlist amilist">
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Cabana
                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Gazebo
                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Juice Bar
                                            </li>
                                            <li class="text-white">
                                                <!-- <div><img src="<?php echo $assetBase; ?>images/bullet2.webp"></div> -->
                                                Viewing Deck
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- -------------------->

        </div>
    </section>

    <section class="sec-location" id="Location">
        <div class="cust-conatiner">
            <div class="sec-tittle">
                <h2 data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">Location</h2>
                <div class="headline"></div>
            </div>
            <div style="width: 100%;height: 10px;"></div>
            <p class="text-center" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                Elevate your stature by relocating to an esteemed location, where refinement meets exclusivity in
                perfect harmony. Positioned within a coveted enclave, this prestigious destination grants unmatched
                prestige, elevating your name and reputation with a whisper of distinction.

            </p>
            <!-- <p class="loc-hightxt" data-aos="fade-up" data-aos-delay="700" data-aos-duration="1000">
                MINUTES AWAY FROM MAJOR BUSINESS PARKS <span>|</span> EASY CONNECTIVITY TO AIRPORTS <span>|</span>
                ACCESSIBLE BY MAJOR CONNECTING ROADS
            </p> -->

            <div style="width: 100%;height: 50px;"></div>
            <div class="sppb-row">

                <div class="sppb-col-sm-6 col-md-6 ">
                    <div class="locimg"> <a data-fancybox="map" href="images/MAP.jpg">
                            <img class="pop-loc" src="images/MAP.jpg">
                        </a></div>
                    <p style="font-size:12px; text-align:center; color:white;">Distances as Per Google Maps.</p>

                </div>


                <div class="col-md-6 pd0-m">
                    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingOne">
                                <h4 class="panel-title">
                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne" class="">
                                        INFRASTRUCTURE
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne" aria-expanded="true">
                                <div class="panel-body">

                                    <p>1 . Western Express Way : <span> 5 km</span></p>
                                    <p>2 . National Highway : <span>4 km</span></p>
                                    <p>3 . Proposed Metro Station: <span> 1 km </span></p>

                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingTwo">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        CONNECTIVITY
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo" aria-expanded="false" style="height: 0px;">
                                <div class="panel-body">
                                    <p>1 . Bhayander East Station : <span>2.5 km </span></p>
                                    <p>2 . Mira Road East Station : <span> 2.5 km </span></p>
                                    <p>3 . Mira Bhayander Road: <span>500 mtrs.</span></p>

                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingThree">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        SHOPPING
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree" aria-expanded="false">
                                <div class="panel-body">
                                    <p>1 . Maxus Mall : <span>1.5 KM </span></p>
                                    <p>2 . D-Mart : <span> 1.5 KM </span></p>
                                    <p>3 . Thakur Mall : <span>4 KM </span></p>

                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingFour">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                        EDUCATIONAL
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour" aria-expanded="false">
                                <div class="panel-body">
                                    <p>1 . S.V.P. Vidyalaya : <span>2 KM </span></p>
                                    <p>2 . R.B.K. International School : <span>2.5 KM</span></p>
                                    <p>3 . Ram Ratna International School : <span>8 KM</span></p>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingFive">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                        HEALTH CARE:
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFive" aria-expanded="false">
                                <div class="panel-body">
                                    <p>1 . Bharat Ratna. P.B. Joshi Govt. Hospital : <span>2 KM</span></p>
                                    <p>2 . Wockhardt Hospital : <span>3 KM </span></p>
                                    <p>3 . Bhakti Vedanta Hospital : <span>4 KM </span></p>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>


            </div>

        </div>
    </section>

    <section class="sec-location" id="aboutus">
        <div class="cust-conatiner">
            <div class="sec-tittle">
                <h2 data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000" class="text-white">About Us </h2>
                <div class="headline"></div>
            </div>
            <div style="width: 100%;height: 10px;"></div>
            <p class="text-center text-white" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                Driven by a dedication to quality craftsmanship and unparalleled attention to detail we strive to exceed
                expectations with every project we undertake. Our journey began with a vision to create spaces that
                inspire, elevate and endure. Each development is meticulously designed, blending timeless elegance with
                modern sophistication.

            </p>

            <div class="row abo">
                <div class="col-md-2 ab">
                    <img src="images/aboutusicon/3.png" alt="about">
                    <h3>Developed and delivered the most expensive project on Mira Road, Indraprasth
                    </h3>
                </div>

                <div class="col-md-2 ab">
                    <img src="images/aboutusicon/4.png" alt="about">
                    <h3>282+ Delivered projects</h3>
                </div>

                <div class="col-md-2 ab">
                    <img src="images/aboutusicon/1.png" alt="about">
                    <h3>Established real estate brand in Mira-Road and Bhayander</h3>
                </div>

                <div class="col-md-2 ab">
                    <img src="images/aboutusicon/5.png" alt="about">
                    <h3>40 Lakhs Sq. Ft. Delivered</h3>
                </div>

                <div class="col-md-2 ab">
                    <img src="images/aboutusicon/2.png" alt="about">
                    <h3>Well known for project delivery and construction quality</h3>
                </div>

                <div class="col-md-2 ab lastsectionami" style="border: none;">
                    <img src="images/aboutusicon/6.png" alt="about">
                    <h3>6000+ happy customers</h3>
                </div>

            </div>


            <!-- <div style="width: 100%;height: 50px;"></div> -->

            <!-- <div class="row mr0">
                <a href="javascript:void (0);" class="map-btn map-click">View Google Map</a>
            </div> -->

        </div>
    </section>

    <!-- <section class="full-imgsec scroll-wrap4" style="background:#e2bb6c;">
        <div class="full-secoverlay item-center">
            <div>
                <h2 style="letter-spacing: 3px;" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                    Ready-to-move-in opulent Terrace Residences With Private Sundecks And Plunge Pools
                </h2>
                <img class="rellax4 a4-scroll" data-rellax-speed="2" src="<?php echo $assetBase; ?>images/A2.webp">
            </div>
        </div>
    </section> -->

    <section class="sec-gallery light-grey" id="Gallery">
        <div class="container">
            <div class="sec-tittle">
                <h2 data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">Gallery</h2>
                <div class="headline"></div>
            </div>

            <!-- Nav tabs -->
            <ul class="nav nav-tabs mytab" role="tablist">
                <li role="presentation" class="active">
                    <a href="#view" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">View
                    </a>
                </li>
                <!-- <li role="presentation" class="">
                    <a href="#floorplan" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">Floor
                        Plan
                    </a>
                </li> -->
                <li role="presentation" class="">
                    <a href="#amenitiesplan" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">
                        Amenities
                    </a>
                </li>
            </ul>

            <div class="tab-content">
                <!-- ======================================== -->

                <div role="tabpanel" class="tab-pane fade active in" id="view">
                    <div class="tab-content-wrap">
                        <div class="col-md-12 gall-pd">
                            <div class="col-md-12 pd0">
                                <div class="amenities-gallery">
                                    <img src="<?php echo $assetBase; ?>images/build-view.webp" alt="one arc building view">
                                    <p class="imagepatch">Actual View</p>
                                    <a href="<?php echo $assetBase; ?>images/build-view.webp" data-fancybox="view" data-caption="">
                                        <div class="ami-overlay">
                                            <div class="d-flex">
                                                <!-- <h3></h3> -->
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>

                        </div>


                    </div>
                </div>

                <!-- <div role="tabpanel" class="tab-pane fade" id="floorplan">
                    <div class="tab-content-wrap">
                        <div class="col-md-3 gall-pd">
                            <div class="amenities-gallery">
                                <img src="<?php echo $assetBase; ?>images/gallery/floor/t-1.webp" alt="">
                                <a href="javascript:void (0);" class="floorclick">
                                    <div class="ami-overlay">
                                        <div class="d-flex">
                                      
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-3 gall-pd">
                            <div class="amenities-gallery">
                                <img src="<?php echo $assetBase; ?>images/gallery/floor/t-2.webp" alt="">
                                <a href="javascript:void (0);" class="floorclick">
                                    <div class="ami-overlay">
                                        <div class="d-flex">
                                      
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-3 gall-pd">
                            <div class="amenities-gallery">
                                <img src="<?php echo $assetBase; ?>images/gallery/floor/t-3.webp" alt="">
                                <a href="javascript:void (0);" class="floorclick">
                                    <div class="ami-overlay">
                                        <div class="d-flex">
                                         
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-3 gall-pd">
                            <div class="amenities-gallery">
                                <img src="<?php echo $assetBase; ?>images/gallery/floor/t-4.webp" alt="">
                                <a href="javascript:void (0);" class="floorclick">
                                    <div class="ami-overlay">
                                        <div class="d-flex">
                                          
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="col-md-3 gall-pd">
                            <div class="amenities-gallery">
                                <img src="<?php echo $assetBase; ?>images/gallery/master-t.webp" alt="">
                                <a href="javascript:void (0);" class="floorclick">
                                    <div class="ami-overlay">
                                        <div class="d-flex">
                                           
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>

                    </div>
                </div> -->
                <div role="tabpanel" class="tab-pane fade" id="amenitiesplan">
                    <div class="container">
                        <div class="tab-content">

                            <div class="amenitiesSlider owl-carousel owl-theme">
                                <div class="item">
                                    <div class="amenities-gallery">
                                        <img src="<?php echo $assetBase; ?>images/ame/ame1.webp" alt="">
                                        <a href="<?php echo $assetBase; ?>images/ame/ame1.webp" data-fancybox="view" data-caption="">
                                            <div class="patch left">
                                                <p class="">Kids’ Play Area</p>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery">
                                        <img src="<?php echo $assetBase; ?>images/ame/ame2.webp" alt="">
                                        <a href="<?php echo $assetBase; ?>images/ame/ame2.webp" data-fancybox="view" data-caption="">
                                            <div class="patch left">
                                                <p class="">Yoga Centre</p>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery">
                                        <img src="<?php echo $assetBase; ?>images/ame/ame3.webp" alt="">
                                        <a href="<?php echo $assetBase; ?>images/ame/ame3.webp" data-fancybox="view" data-caption="">
                                            <div class="patch left">
                                                <p class="">Gym</p>
                                            </div>
                                        </a>
                                    </div>

                                </div>
                                <div class="item">
                                    <div class="amenities-gallery">
                                        <img src="<?php echo $assetBase; ?>images/ame/ame4.webp" alt="">
                                        <a href="<?php echo $assetBase; ?>images/ame/ame4.webp" data-fancybox="view" data-caption="">
                                            <div class="patch left">
                                                <p class="">Terrace Turf</p>
                                            </div>
                                        </a>
                                    </div>

                                </div>
                                <div class="item">
                                    <div class="amenities-gallery">
                                        <img src="<?php echo $assetBase; ?>images/ame/ame5.webp" alt="">
                                        <a href="<?php echo $assetBase; ?>images/ame/ame5.webp" data-fancybox="view" data-caption="">
                                            <div class="patch left">
                                                <p class="">Swimming Pool</p>
                                            </div>
                                        </a>
                                    </div>

                                </div>
                                <div class="item">
                                    <div class="amenities-gallery">
                                        <img src="<?php echo $assetBase; ?>images/ame/ame6.webp" alt="">
                                        <a href="<?php echo $assetBase; ?>images/ame/ame6.webp" data-fancybox="view" data-caption="">
                                            <div class="patch left">
                                                <p class="">Movie Theatre</p>
                                            </div>
                                        </a>
                                    </div>

                                </div>


                            </div>

                        </div>
                    </div>

                </div>

            </div>

        </div>
    </section>


    <section id="Contactus" class="contact-sec">
        <div class="contact-overlay">
            <div class="container">

                <div class="sec-tittle">
                    <h2 style="color: #ffffff;" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                        Contact Us
                    </h2>
                    <div class="headline"></div>
                </div>
                <div style="width: 100%;height: 10px;"></div>


                <p class="form-txt">Please Enter Your Details To Know More About Sonam One Arc</p>

                <form id="contact-form" action="thank-you.php" name="contact-form" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('contact-form');">
                    <div class="form-group col-md-6">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-user form-ico" aria-hidden="true"></i>
                            </div>
                            <input type="text" class="form-control" name="fname" placeholder="Name">
                            <input type="hidden" id="source" name="source" value="Contact Form">
                        </div>
                        <label for="fname" class="error"></label>
                    </div>
                    <div class="form-group col-md-6">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                            </div>
                            <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                        </div>
                        <label for="mobile" class="error"></label>
                    </div>
                    <div class="form-group col-md-12">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                            <input type="email" class="form-control" name="email" placeholder="Email">
                        </div>
                        <label for="email" class="error"></label>
                    </div>
                    <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
                </form>

                <h3 class="form-calltxt">Site Address :</h3>
                <h3 style="margin-top: 2%" class="form-txt">ONE ARC Sales Lounge, Opp. Mithalal Jain Bunglow, 100 Feet
                    Road, Bhayandar East - 401107</h3>

                <p class="form-calltxt">
                    Call: <a href="tel:02268680003">022-68680003</a>
                </p>


            </div>
        </div>
    </section>
    <footer class="footer-sec">
        <div class="container">
            <p>
                <!-- The Sonam One Arc : OC Received -->
            </p>
            <p>View Our <a href="javascript:void (0);" class="disc-btn">Disclaimer</a></p>
            <p>Copyright © Sonam One Arc 2024. All rights reserved.</p>
        </div>
    </footer>
    <div class="privacy">
        <div class="container">

            <div class="row foot-wrap">

                <div class="col-4 qr-wrap">
                    <img src="<?php echo $assetBase; ?>images/one-arc-qrcode.webp" class="img-qrcode" alt="one arc qr code">
                </div>
                <div class="col-8 privacy-wrap">
                    <div>
                        <p>
                            <span>Privacy Policy:</span><br>
                            We collect information from you when you register on our site or fill out a form. When
                            filling out a
                            form on
                            our site, for any of the above-mentioned reasons, you may be asked to enter your: name,
                            e-mail address
                            and
                            phone number. You may, however, visit our site anonymously. Any of the information we
                            collect from you
                            is to
                            personalize your experience, to improve our website and to improve customer service. Any
                            data collected
                            <span>will
                                be / will not</span> be shared with any 3rd party.
                        </p>
                        <p>MahaRERA Registration No: P51700031137and information is available at the website
                            <a href="http://maharera.mahaonline.gov.in" target="_blank">http://maharera.mahaonline.gov.in</a>
                            under registered projects.
                        </p>
                    </div>

                </div>
            </div>



        </div>
    </div>

    <div id="pageloader">
        <div class="loading-wrap">
            <img src="<?php echo $assetBase; ?>images/Extraction_17.webp">
        </div>
    </div>

    <div class="col-lg-12 col-sm-12 col-xs-12 fixed-footer-cust hidden-md hidden-lg hidden-sm">
        <div class="container">
            <div class="col-lg-6 col-sm-6 col-xs-6 div-line pd0">
                <a href="tel:02268770063" class="fix-link callme">
                    <i class="fa fa-phone f-icon" aria-hidden="true"></i>
                    CALL NOW
                </a>
            </div>
            <div class="col-lg-6 col-sm-6 col-xs-6 pd0">
                <button class="btn fix-link i-am"><i class="fa fa-envelope"></i> ENQUIRE NOW</button>
            </div>
        </div>
    </div>


    <!-- ================ main pop ==================== -->
    <!-- <div class="modal fade in" tabindex="-1" role="dialog" id="main-modal" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <img src="<?php echo $assetBase; ?>images/Extraction_17.webp" alt="">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h3>Express Your Interest</h3>
                    <p>Please Enter Your Details To Know More About Sonam One Arc</p>
                    <form id="main-popup" action="thank-you.php" name="main-popup" method="POST" novalidate="novalidate"
                        onsubmit="return save_landing_pageinfo('main-popup');">
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" id="source" name="source" value="Main PopUp">
                            </div>
                            <label for="fname" class="error"></label>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="mobile" class="error"></label>
                        </div>
                     
                        <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
                    </form>
                </div>
            </div>
        </div>
    </div> -->

    <!-- ============================================= -->

    <!-- ================ price pop ==================== -->
    <div class="modal fade in" tabindex="-1" role="dialog" id="price-modal" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <img src="<?php echo $assetBase; ?>images/Extraction_17.webp" alt="">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h3 id="poptitle">Price</h3>
                    <p>Please Enter Your Details To Know More About Sonam One Arc</p>
                    <form id="price-popup" action="thank-you.php" name="price-popup" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('price-popup');">
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" id="source" name="source" value="Price PopUp">
                            </div>
                            <label for="fname" class="error"></label>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="mobile" class="error"></label>
                        </div>
                        <div class="form-group col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                </div>
                                <input type="email" class="form-control" name="email" placeholder="Email">
                            </div>
                            <label for="email" class="error"></label>
                        </div>
                        <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- ============================================= -->

    <a href="images/one-arc-brochure.pdf" download id="download-file"></a>
    <button class="btn btn-danger interested hidden-xs">Download E-Brochure</button>
    <!-- ================ I AM ==================== -->
    <div class="modal fade in" tabindex="-1" role="dialog" id="interested" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <img src="<?php echo $assetBase; ?>images/Extraction_17.webp" alt="">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h3>Express Your Interest</h3>
                    <p>Please Enter Your Details To Know More About Sonam One Arc</p>
                    <form id="enquire-now" action="thank-you.php" name="enquire-now" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('enquire-now');">
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" id="source" name="source" value="Enquire Now">
                            </div>
                            <label for="fname" class="error"></label>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="mobile" class="error"></label>
                        </div>
                        <div class="form-group col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                </div>
                                <input type="email" class="form-control" name="email" placeholder="Email">
                            </div>
                            <label for="email" class="error"></label>
                        </div>
                        <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- ============================================= -->


    <!-- ================ Download Broucher ==================== -->
    <div class="modal fade in" tabindex="-1" role="dialog" id="broucher-modal" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <img src="<?php echo $assetBase; ?>images/Extraction_17.webp" alt="">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h3>Download Brochure</h3>
                    <p>Please Enter Your Details To Know More About Sonam One Arc</p>
                    <form id="brochure-form" action="thank-you.php" name="brochure-form" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('brochure-form');">
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" id="source" name="source" value="Download Brochure">
                            </div>
                            <label for="fname" class="error"></label>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                </div>
                                <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="mobile" class="error"></label>
                        </div>
                        <div class="form-group col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                </div>
                                <input type="email" class="form-control" name="email" placeholder="Email">
                            </div>
                            <label for="email" class="error"></label>
                        </div>
                        <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- ============================================= -->


    <div class="modal fade in" tabindex="-1" role="dialog" id="disclaimer" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <img src="<?php echo $assetBase; ?>images/Extraction_17.webp" alt="">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>

                    <h3 id="poptitle">Disclaimer</h3>
                    <div class="disc-wrap">
                        <p>
                            This advertisement/printed material does not constitute an offer or contract of any nature
                            whatsoever between
                            the promoters and the recipient. All transactions in this development shall be subject to
                            and
                            governed by the
                            terms &amp; conditions of the agreement for sale to be entered into between the parties. All
                            internal dimensions for
                            carpet area are from unfinished wall surfaces. Minor variations up to (+/-)3% in actual
                            carpet
                            areas may occur
                            on account of site conditions /columns /finishes etc. In toilets, the carpet areas are
                            inclusive
                            of ledge walls ( if
                            any). Conversion: 1 sq. mtr. = 10.764 sq. ft. *T&amp;C Apply
                        </p>
                        <p>
                            MahaRERA Registration No: P51700031137and information is available at the website
                            <a href="http://maharera.mahaonline.gov.in" target="_blank">http://maharera.mahaonline.gov.in</a>
                            under registered projects.
                        </p>
                    </div>

                    <button style="width: 70px;margin: 0 auto; display: block;" type="button" class="btn price-btn" data-dismiss="modal" aria-label="Close">
                        OK
                    </button>

                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- ============================================= -->


    <div class="modal fade in" tabindex="-1" role="dialog" id="mapPop" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <img src="<?php echo $assetBase; ?>images/Extraction_17.webp" alt="">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>

                    <h3 id="poptitle">Google Map</h3>

                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3765.614608218315!2d72.8624749!3d19.2991188!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b1a6a7820e41%3A0xa9fec9a6133f467!2sSonam%20Opulance!5e0!3m2!1sen!2sin!4v1712129522462!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- ============================================= -->

    <!-- owl carousal -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> -->





    <!-- Optional JavaScript -->
    <script src="<?php echo $assetBase; ?>js/jquery.min.js"></script>
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>-->
    <!--Menu Link-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/main.js"></script>
    <!--End Menu Link-->

    <script src="<?php echo $assetBase; ?>js/plugin.min.js"></script>
    <script src="<?php echo $assetBase; ?>js/cookie.js"></script>
    <!--<script src="<?php echo $assetBase; ?>js/mobilevalidate.js"></script>-->
    <script src="<?php echo $assetBase; ?>js/custome.js"></script>
    <script>
        Delete_Cookie('formfilled');
    </script>
    <script>
        $('.amenitiesSlider').owlCarousel({
            loop: true,
            autoplay: true,
            autoplayTimeout: 2000,
            margin: 10,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    nav: true,
                    loop: true
                },
                600: {
                    items: 3,
                    nav: false,
                    loop: true
                },
                1000: {
                    items: 2,
                    nav: true,
                    loop: true
                }
            }
        })
    </script>
    <!-- <script>
    $(".menu-close").on("click", function() {
        $("#logo").toggleClass("animateSlow");

        console.log("click");

    }); -->
    </script>
    <script type="text/javascript">
        function save_landing_pageinfo(elm) {
            jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', true);
            setTimeout(function() {
                jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', false);
            }, 5000);
            var name = jQuery('#' + elm + ' input[name="fname"]').val();
            var mobileno = jQuery('#' + elm + ' input[name="mobile"]').val();
            var emailid = jQuery('#' + elm + ' input[name="email"]').val();
            var message = jQuery('#' + elm + ' textarea[name="message"]').val();
            var fsource = jQuery('#' + elm + ' input[name="source"]').val();
            var current_url = location.hostname;

            if (name == "") {
                //alert("Please Enter Your Name");
                return false;
            }
            mobileno = mobileno.replace(/[^0-9]/g, '');
            if (mobileno.length != 10) {
                //alert("Please Enter 10 Digit Mobile Number");
                return false;
            }
            if (elm == 'main-popup') {
                emailid = "";
            } else {
                var atpos = emailid.indexOf("@");
                var dotpos = emailid.lastIndexOf(".");
                if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= emailid.length) {
                    return false;
                }
            }
            if (message == undefined) {
                message = "";
            }
            if (name != "" && mobileno != "") {
                $("#pageloader").fadeIn();
                if (elm == 'brochure-form') {
                    console.log('download file now!!');
                    document.getElementById('download-file').click();
                }
                return true;
            }
            return false;
        }

        function submitForm(elm) {
            document.createElement('form').submit.call(document.getElementById(elm));
        }
    </script>



</body>

</html>