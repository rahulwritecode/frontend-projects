<?php

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);


session_start();
$mobile = $_REQUEST['mobile'];
$email = $_REQUEST['email'];
$message = $_REQUEST['message'];

$request = $_SERVER['REQUEST_METHOD'];

$name = $_REQUEST['fname'];
if ($request !== 'POST') {
    http_response_code(405);
    echo 'Method Not Allowed';
    echo '</br>';
    echo "<a href='/'>Go Back</a>";
    die;
}

if ($_REQUEST['mobile'] == '') {
    echo 'Please enter valid mobile number';
    echo '</br>';
    echo "<a href='/'>Go Back</a>";
    die;
}
if (ctype_alpha(str_replace(' ', '', $name)) === false) {
    echo 'Please enter valid Name';
    echo '</br>';
    echo "<a href='/'>Go Back</a>";
    die;
}


if (strlen($_REQUEST['mobile']) !== 10) {
    echo 'Please enter valid mobile number';
    echo '</br>';
    echo "<a href='/'>Go Back</a>";
    die;
}
if(!preg_match('/^[6789]\d{9}$/', $_POST['mobile']))
    {
        echo 'Please enter valid mobile number';
        echo '</br>';
        echo "<a href='/'>Go Back</a>";
        die;
    }
    $regex = '/^[A-Za-z][a-z\s]*( [A-Z][a-z]*)?$/';

    if(!preg_match($regex, $name)) {
       echo 'Please enter valid Name';
       echo '</br>';
       echo 'please enter name without uppercase character in between';
        echo '</br>';
        echo "<a href='/'>Go Back</a>";
        die;
    }



require_once 'send_leads.php';

$postData = new PostData();

if ((!isset($_COOKIE['formfilled'])) && isset($_REQUEST['mobile'])) {

   $postData->callback();
    setcookie('formfilled', 'yes');
} 
?>


<!doctype html>
<html lang="en">

<head>
    <!-- Google Tag Manager -->

    <!-- End Google Tag Manager -->
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Ascendant Collection | Thank You</title>
    <link rel="icon" href="<?php echo $assetBase; ?>images/favicon-logo.webp" type="image/png" sizes="16x16">
    <!-- Bootstrap CSS -->
    <!-- Latest compiled and minified bootstrap CSS -->
    <link rel="stylesheet" href="css/plugin.min.css">

    <!--Menu css files-->
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/menu.css">
    <!--End Menu css files-->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/fonts.css">
    <style>
    .navigation-type-split .inner-wrapper .right-side .menu-toggle .bars .toggle-bar {
        background-color: #ffffff;
    }
    </style>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->

    <!-- End Google Tag Manager (noscript) -->

    <nav id="homenavigation" class="navigation navigation-type-split">
        <div class="inner-wrapper">
            <div class="left-side">
                <!--menu toggle-->
                <!--<div class="menu-toggle toggle-text-slider">
                <div class="bars">
                    <span class="toggle-bar"></span>
                    <span class="toggle-bar"></span>
                    <span class="toggle-bar"></span>
                </div>
                <div class="menu-toggle-text">
                        <span>
                            menu
                        </span>
                </div>
            </div>-->
                <!--logo-->
                <div class="logo-wrapper">
                    <a href="index.php">
                        <img src="<?php echo $assetBase; ?>images/logo.webp" alt="logo" class="logo">
                    </a>
                </div>
            </div>

            <div class="right-side">
                <a href="index.php" class="menu-getintouch">Go Back</a>
                <div class="menu-toggle toggle-text-slider">

                    <div class="bars">
                        <span class="toggle-bar"></span>
                        <span class="toggle-bar"></span>
                        <span class="toggle-bar"></span>
                    </div>
                    <!--<div class="menu-toggle-text">
                        <span>
                            menu
                        </span>
                </div>-->
                </div>
            </div>
        </div>
    </nav>

    <!-- <img src="<?php echo $assetBase; ?>images/inner-img.webp"> -->

    <section class="sec-thankyou">
        <div class="container">

            <div class="wrap" style="padding:15px;height:auto !important;">

                <span class="msgicon" aria-hidden="true"><i class="fa fa-check" aria-hidden="true"></i></span>
                <h2 class="oops"><span>You're</span> All Set!</h2>
                <h3 class="oops-greet" style="text-align:center;">Greetings from Sonam One ARC</h3>
                <h3 class="oops-subtitle" style="text-align:center;">
                    Thank you for your Interest.<br />
                    Our Sales Manager will get in touch with you shortly.
                </h3>
                <a href="index.php" style="text-decoration: none;">
                    <h2 class="go-home">
                        <span class="" aria-hidden="true">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i>
                        </span> GO BACK TO HOME
                    </h2>
                </a>

            </div>

        </div>
    </section>

    <footer class="footer-sec">
        <div class="container">
            <p>
                <!-- The Sonam One Arc : OC Received -->
            </p>
            <p>View Our <a href="javascript:void (0);" class="disc-btn">Disclaimer</a></p>
            <p>Copyright © Sonam One Arc 2024. All rights reserved.</p>
        </div>
    </footer>
    <div class="privacy">
        <div class="container">

            <div class="row foot-wrap">

                <div class="col-4 qr-wrap">
                    <img src="<?php echo $assetBase; ?>images/one-arc-qrcode.webp" class="img-qrcode"
                        alt="one arc qr code">
                </div>
                <div class="col-8 privacy-wrap">
                    <div>
                        <p>
                            <span>Privacy Policy:</span><br>
                            We collect information from you when you register on our site or fill out a form. When
                            filling out a
                            form on
                            our site, for any of the above-mentioned reasons, you may be asked to enter your: name,
                            e-mail address
                            and
                            phone number. You may, however, visit our site anonymously. Any of the information we
                            collect from you
                            is to
                            personalize your experience, to improve our website and to improve customer service. Any
                            data collected
                            <span>will
                                be / will not</span> be shared with any 3rd party.
                        </p>
                        <p>MahaRERA Registration No: P51700031137and information is available at the website
                            <a href="http://maharera.mahaonline.gov.in"
                                target="_blank">http://maharera.mahaonline.gov.in</a>
                            under registered projects.
                        </p>
                    </div>

                </div>
            </div>



        </div>
    </div>


    <div class="modal fade in" tabindex="-1" role="dialog" id="disclaimer" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <img src="<?php echo $assetBase; ?>images/poplogo.webp" alt="">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>

                    <h3 id="poptitle">Disclaimer</h3>
                    <div class="disc-wrap">
                        <p>
                            This advertisement/printed material does not constitute an offer or contract of any nature
                            whatsoever between
                            the promoters and the recipient. All transactions in this development shall be subject to
                            and
                            governed by the
                            terms &amp; conditions of the agreement for sale to be entered into between the parties. All
                            internal dimensions for
                            carpet area are from unfinished wall surfaces. Minor variations up to (+/-)3% in actual
                            carpet
                            areas may occur
                            on account of site conditions /columns /finishes etc. In toilets, the carpet areas are
                            inclusive
                            of ledge walls ( if
                            any). Conversion: 1 sq. mtr. = 10.764 sq. ft. *T&amp;C Apply
                        </p>
                    </div>

                    <button style="width: 70px;margin: 0 auto; display: block;" type="button" class="btn price-btn"
                        data-dismiss="modal" aria-label="Close">
                        OK
                    </button>

                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- ============================================= -->


    <!-- Optional JavaScript -->
    <script src="js/jquery.min.js"></script>
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>-->
    <!--Menu Link-->
    <!--<script src="assets/js/imagesloaded.pkgd.min.js"></script>-->
    <!--<script src="assets/js/TweenMax.min.js"></script>-->
    <!--<script src="assets/js/main.js"></script>-->
    <!--End Menu Link-->

    <script src="js/plugin.min.js"></script>
    <script src="js/cookie.js"></script>
    <script src="js/custome.js"></script>

</body>

</html>