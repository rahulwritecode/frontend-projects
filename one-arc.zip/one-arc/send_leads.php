<?php
class PostData
{
    public function callback()
    {

        $channel = $_COOKIE['cstm_ppc_channel'];
        $campaign = $_COOKIE['cstm_ppc_campaign'];
        $placement = $_COOKIE['cstm_ppc_placement'];
        $keyword = $_COOKIE['cstm_ppc_keyword'];
        $gclid = $_COOKIE['gclid'];

        $fname = $_REQUEST['fname'];
        $lname = $_REQUEST['lname'];
        $email = $_REQUEST['email'];
        $mobile = str_replace(' ', '', $_REQUEST['mobile']);
        $projectname = $_REQUEST['projectname'];
        $source = $_REQUEST['source'];
        $message = $_REQUEST['message'];
        //$country_code = $_REQUEST['country_code'];
        $name = $fname . ' ' . $lname;


        $fullmobile = "91" . $mobile;



        // Google Sheet Interation------------------

        $enqproject = '';

        $postFields = "entry.449648499=" . $name;
        $postFields .= "&entry.1379833540=" . $email;
        $postFields .= "&entry.758332158=" . $fullmobile;
        $postFields .= "&entry.1900106466=" . $message;
        $postFields .= "&entry.1693361781=" . $source;
        $postFields .= "&entry.1264955311=" . $enqproject;

        $postFields .= '&entry.1830911442=' . urlencode($_COOKIE['cstm_ppc_campaign']);
        $postFields .= '&entry.939490048=' . urlencode($_COOKIE['cstm_ppc_channel']);
        $postFields .= '&entry.729166844=' . urlencode($_COOKIE['cstm_ppc_keyword']);
        $postFields .= '&entry.839903606=' . urlencode($_COOKIE['cstm_ppc_placement']);
        $postFields .= '&entry.2003337495=' . urlencode($_COOKIE['cstm_ppc_device']);
        $postFields .= '&entry.874538596=' . $gclid;

        $ch3 = curl_init();
        curl_setopt($ch3, CURLOPT_URL, "https://docs.google.com/forms/u/0/d/e/1FAIpQLSf3GNnmli-VrfxtDgJ_cH8GHWsziLFt8xUUaDsdYnoPdqBKvg/formResponse");
        curl_setopt($ch3, CURLOPT_POST, 1);
        curl_setopt($ch3, CURLOPT_POSTFIELDS, $postFields);
        curl_setopt($ch3, CURLOPT_HEADER, 0);
        curl_setopt($ch3, CURLOPT_RETURNTRANSFER, true);
        $result3 = curl_exec($ch3);




        // do not delete
        return true;
    }
}
