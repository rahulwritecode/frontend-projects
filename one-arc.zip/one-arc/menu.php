<nav id="homenavigation" class="navigation navigation-type-split">
    <div class="inner-wrapper">
        <div class="left-side">
            <!--menu toggle-->
            <!--<div class="menu-toggle toggle-text-slider">
                <div class="bars">
                    <span class="toggle-bar"></span>
                    <span class="toggle-bar"></span>
                    <span class="toggle-bar"></span>
                </div>
                <div class="menu-toggle-text">
                        <span>
                            menu
                        </span>
                </div>
            </div>-->
            <!--logo-->
            <div class="logo-wrapper">
                <a href="index.php">
                    <img src="<?php echo $assetBase; ?>images/logo.webp" alt="logo" class="logo">
                </a>
            </div>
        </div>

        <div class="right-side">
            <a href="javascript:void(0);" class="menu-getintouch getin-touch">Get a Quote</a>
            <div class="menu-toggle toggle-text-slider">

                <div class="bars">
                    <span class="toggle-bar"></span>
                    <span class="toggle-bar"></span>
                    <span class="toggle-bar"></span>
                </div>
                <!--<div class="menu-toggle-text">
                        <span>
                            menu
                        </span>
                </div>-->
            </div>
        </div>
        <!--<ul class="right-side">
            <li class="shop-wrapper">

                <div class="shop-toggle">
                    <div class="icon-wrapper">
                        <i class="fa fa-shopping-basket">
                        </i>
                        <span class="products-count">
                                5
                        </span>
                    </div>
                    <div class="text-slider-wrapper">
                        <span>
                            shop
                        </span>
                    </div>

                    <div class="shop-products-list">
                        <ul>
                            <li>
                                <div class="img-side">
                                    <img src="assets/img/products/prod-6.jpg" alt="prod-1" class="img-fluid">
                                </div>
                                <div class="info-side">
                                    <h6 class="product-title">Flying Ninja</h6>
                                    <div class="product-info">
                                        <span class="price">
                                            $39
                                        </span>
                                        <span class="star-wrapper">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                        </span>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="img-side">
                                    <img src="assets/img/products/prod-7.jpg" alt="prod-1" class="img-fluid">
                                </div>
                                <div class="info-side">
                                    <h6 class="product-title">Woo Logotype</h6>
                                    <div class="product-info">
                                            <span class="price">
                                                $39
                                            </span>
                                        <span class="star-wrapper">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star-half"></i>
                                            </span>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="img-side">
                                    <img src="assets/img/products/prod-8.jpg" alt="prod-1" class="img-fluid">
                                </div>
                                <div class="info-side">
                                    <h6 class="product-title">Ship Your Idea</h6>
                                    <div class="product-info">
                                            <span class="price">
                                                $49
                                            </span>
                                        <span class="star-wrapper">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                        </span>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>

            <li class="search-form-wrapper">
                <div class="search-form">
                    <form>
                        <input type="text" placeholder="Input some keywords...">
                    </form>
                </div>
                <div class="search-toggle toggle-text-slider">
                    <i class="fa fa-search">
                    </i>
                    <div class="text-slider-wrapper">
                        <span>
                            search
                        </span>
                        <span>
                            exit
                        </span>
                    </div>
                </div>
            </li>

            <li class="sidebar-wrapper">
                <div class="sidebar-toggle">
                    <span class="dot"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                </div>
            </li>
        </ul>-->


    </div>
    <!--navigation menu-->
    <div class="navigation-menu-wrapper">
        <!--exit toggle-->
        <div class="menu-close">
            <i class="fa fa-times"></i>
            <div class="menu-toggle-text">
                <span>exit</span>
            </div>
        </div>
        <!--navigation overlay-->
        <div class="navigation-overlay">
            <div class="str str-one"></div>
            <div class="str str-two"></div>
            <div class="str str-three"></div>
            <div class="str str-four"></div>
            <div class="str str-five navigation-image-side"></div>
        </div>
        <!--menu list-->
        <ul class="navigation-menu-list active-list">

            <li class="menu-item" data-navigation-overlay-image="images/menuitem/1.jpg">
                <a href="#home-carousel" class="m-link">
                    <span>
                        Home
                    </span>
                </a>
            </li>

            <li class="menu-item" data-navigation-overlay-image="images/menuitem/2.jpg">
                <a href="#Overview" class="m-link">
                    <span>
                        Overview
                    </span>
                </a>
            </li>


            <li class="menu-item" data-navigation-overlay-image="images/menuitem/3.jpg">
                <a href="#projectsHighlight" class="m-link">
                    <span>
                        Project Highlight
                    </span>
                </a>
            </li>

            <li class="menu-item" data-navigation-overlay-image="images/menuitem/1.jpg">
                <a href="#configuration" class="m-link">
                    <span>
                        Configuration
                    </span>
                </a>
            </li>

            <li class="menu-item" data-navigation-overlay-image="images/menuitem/2.jpg">
                <a href="#Amenities" class="m-link">
                    <span>
                        Amenities
                    </span>
                </a>
            </li>

            <li class="menu-item" data-navigation-overlay-image="images/menuitem/3.jpg">
                <a href="#Location" class="m-link">
                    <span>
                        Location
                    </span>
                </a>
            </li>

            <!--<li class="menu-item"
                data-navigation-overlay-image="images/menuitem/1.jpg">
                <a href="r-club.php">
                        <span>
                            R Club
                        </span>
                </a>
            </li>-->

            <li class="menu-item" data-navigation-overlay-image="images/menuitem/1.jpg">
                <a href="#Gallery" class="m-link">
                    <span>
                        Gallery
                    </span>
                </a>
            </li>

            <li class="menu-item" data-navigation-overlay-image="images/menuitem/2.jpg">
                <a href="#Contactus" class="m-link">
                    <span>
                        Contact Us
                    </span>
                </a>
            </li>

        </ul>

        <!--additional information for menu (custom)-->
        <div class="navigation-information">

            <div class="navigation-animate-element">
                <div class="animatelogo">
                    <img class="menulogo" id="logo" src="images/sonamlogo.png" alt="logo">
                </div>

                <h3 class="main-title">Get In Touch With Us</h3>
                <!--<p class="subtitle"></p>-->
            </div>
            <div class="two-side-contact navigation-animate-element">
                <div class="contact-side">
                    <p class="contact-title">Sonam One Arc</p>
                    <p class="contact-info">
                        ONE ARC Lounge, Opp Mithalal Jain Bunglow, 100 Feet Road, Bhayander East- 401107
                    </p>
                </div>
                <!--<div class="contact-side">
                    <p class="contact-title">Email us</p>
                    <p class="contact-info block-reveal-wrapper" data-fx="1">
                        <a href="mailto:contact@runwal.com" class="reveal-block-link"
                           data-img="assets/reveal-img-1.jpg">
                            contact@runwal.com
                        </a>
                        <a href="mailto:contact@runwalgardens.com" class="reveal-block-link"
                           data-img="assets/reveal-img-1.jpg">
                            sales@avighna.in
                        </a>
                    </p>
                </div>-->
                <div class="contact-side">
                    <p class="contact-title">Call Us</p>
                    <p class="contact-info block-reveal-wrapper" data-fx="5">
                        <a href="tel:02268680003" class="reveal-block-link" data-img="assets/reveal-img-2.jpg">
                            022 68680003
                        </a>
                        <!--<a href="#" class="reveal-block-link"
                           data-img="assets/reveal-img-2.jpg">
                            +91 8652844462
                        </a>-->
                    </p>
                </div>
                <!--<div class="contact-side">
                    <p class="contact-title">Site Address</p>
                    <p class="contact-info">
                        M. P. MARG, NEAR ITC GRAND CENTRAL,
                        LOWER PAREL (EAST), MUMBAI - 400 012
                    </p>
                </div>-->
            </div>
        </div>


    </div>
    <!--mobile search form-->
    <div class="mobile-search-form">
        <span class="exit-toggle">exit <i class="fa fa-times"></i></span>
        <form class="search-form">
            <input type="text" placeholder="Input some keywords...">
            <button type="submit">
                <i class="fa fa-search"></i>
            </button>
        </form>
    </div>
</nav>