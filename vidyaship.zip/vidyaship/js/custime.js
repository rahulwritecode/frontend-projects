jQuery(document).ready(function ($) {

    Delete_Cookie('formfilled');

    $(".price-click").click(function () {
        $('#price-modal').modal('show');
    });

    $(".i-am").click(function () {
        $('#interested').modal('show');
    });

    $(".interested").click(function () {
        $('#interested').modal('show');
    });

    $(".floorclick").click(function () {
        $('#floormodal').modal('show');
    });

    $(".dbclick").click(function () {
        $('#floormodal').modal('show');
        $('.form-title').html('Download Brochure');
        $('.source').val('Download Brochure');
    });

    $(".visit").click(function () {
        $('#visit').modal('show');
    });

    $('.gallery-carousel').owlCarousel({
        items: 1,
        loop: true,
        margin: 25,
        autoplay: true,
        autoplayTimeout: 4000,
        smartSpeed: 1500,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        navText: ["<img src='images/left.png'>", "<img src='images/right.png'>"],
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 3
            }
        }
    });


    $('.amenities-carousel').owlCarousel({
        items: 1,
        loop: true,
        margin: 25,
        autoplay: true,
        autoplayTimeout: 4000,
        smartSpeed: 1500,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        navText: ["<img src='images/left.png'>", "<img src='images/right.png'>"],
        responsive: {
            0: {
                items: 2
            },
            768: {
                items: 5
            }
        }
    });

    $('.floorplan-carousel').owlCarousel({
        items: 1,
        // loop: true,
        margin: 25,
        // autoplay: true,
        autoplayTimeout: 4000,
        smartSpeed: 1500,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        navText: ["<img src='images/left.png'>", "<img src='images/right.png'>"],
        responsive: {
            0: {
                items: 1,
                autoplay: true,
                loop: true
            },
            768: {
                items: 3,
                autoplay: false,
                loop: false
            }
        }
    });

    $('.floorplan-carousel2').owlCarousel({
        items: 1,
        loop: true,
        margin: 25,
        autoplay: true,
        autoplayTimeout: 4000,
        smartSpeed: 1500,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        navText: ["<img src='images/left.png'>", "<img src='images/right.png'>"],
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 3
            }
        }
    });


    $('[data-fancybox="map"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            'zoom',
            'fullScreen',
            'close'
            //'download'
        ],
        thumbs: {
            autoStart: false
        }
    });

    $('[data-fancybox="apt"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            'zoom',
            'fullScreen',
            'close'
            //'download'
        ],
        thumbs: {
            autoStart: false
        }
    });

    $('[data-fancybox="map"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            'zoom',
            'fullScreen',
            'close'
            //'download'
        ],
        thumbs: {
            autoStart: false
        }
    });

    $('[data-fancybox="row"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            'zoom',
            'fullScreen',
            'close'
            //'download'
        ],
        thumbs: {
            autoStart: false
        }
    });

    $('[data-fancybox="floor1"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            'zoom',
            'fullScreen',
            'close'
            //'download'
        ],
        thumbs: {
            autoStart: false
        }
    });
    $('[data-fancybox="floor2"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            'zoom',
            'fullScreen',
            'close'
            //'download'
        ],
        thumbs: {
            autoStart: false
        }
    });
    $('[data-fancybox="floor3"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            'zoom',
            'fullScreen',
            'close'
            //'download'
        ],
        thumbs: {
            autoStart: false
        }
    });
    $('[data-fancybox="floor4"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            'zoom',
            'fullScreen',
            'close'
            //'download'
        ],
        thumbs: {
            autoStart: false
        }
    });


    //Menu Smooth Scroll
    $(".m-link").on('click', function (event) {

        // Make sure this.hash has a value before overriding default behavior
        if (this.hash !== "") {
            // Prevent default anchor click behavior
            event.preventDefault();

            // Store hash
            var hash = this.hash;

            // Using jQuery's animate() method to add smooth page scroll
            // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area

            $('html, body').animate({
                scrollTop: $(hash).offset().top
            }, 800, function () {
                // Add hash (#) to URL when done scrolling (default click behavior)
                // window.location.hash = hash;
            });
        } // End if
    });

});