<!DOCTYPE html>

<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <link rel="stylesheet" href="https://cdn.rawgit.com/michalsnik/aos/2.0.4/dist/aos.css" />

    <link rel="stylesheet" href="css/style.css">

</head>

<body>
    <header class="">
        <nav class="navbar navbar-expand-lg  navbar-light sticky-fixed bg-nav ">
            <div class="container">
                <a class="navbar-brand" href="#"><img class="img-fluid" src="images/logo.png"></a>
                <button class="btn m-auto btn-outline-success d-block d-md-none" type="submit">Get Info</button>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse justify-content-end navbar-collapse" id="navbarNav">
                    <div class="row w-100 justify-content-center">
                        <div class="col-md-10 m-0">
                            <ul class="navbar-nav  justify-content-center">
                                <li class="nav-item">
                                    <a class="nav-link active" aria-current="page" href="#overview">Creative</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#visionery">Visionary</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#divercity">encourage</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="#ourprogram">Programs</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="#infinite">INFINITE</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="#leader">Leaders</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="#student">Activity</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="#learning">Experience</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="#stduents">Feedback</a>
                                </li>

                            </ul>
                        </div>


                        <div class="col-md-2 m-auto text-start d-none d-md-block">
                            <button class="btn m-auto btn-outline-success btnbg" type="submit">Get Info</button>

                        </div>
                    </div>
                </div>

            </div>
        </nav>
    </header>
    <section class="main-banner">
        <div class="banner-inner ">
            <img src="images/banner.jpg" class="d-none d-md-block  w-100 vh-100" alt="...">
            <img src="images/mbanner.png" class="d-block d-md-none w-100 " alt="...">


        </div>

        <div class="carousel-caption">

            <div class="container">
                <div class="d-md-flex d-sm-block d-xs-block align-items-center  justify-content-end">
                    <div class="">
                        <div class="visualtxt " data-aos="fade-right" data-aos-offset="300" data-aos-easing="ease-in-sine" data-aos-delay="200" data-aos-duration="1000">
                            <p>
                                <span class="linetext b-clr">VISUALISE</span><br>

                                <span class="strike"> IMAGINE</span>
                                CREATIVELY
                            </p>

                        </div>
                        <div class="visualtxt boldtxt d-flex" data-aos="fade-right" data-aos-offset="300" data-aos-easing="ease-in-sine" data-aos-delay="400" data-aos-duration="1000">
                            <p>
                                <span class="normaltxt">Be</span> BOLD
                            </p>
                            <img class="arrimg d-none d-md-block" src="images/arrowani.svg" alt="">
                        </div>
                        <div class="bansmltxt " data-aos="fade-right" data-aos-offset="300" data-aos-easing="ease-in-sine" data-aos-delay="600" data-aos-duration="1000">
                            <p>BACHELOR OF DESIGN</p>
                            <p><span>(Communication Design)</span>
                            </p>
                            <div class="row">

                                <div class="col-md-4 col-lg-5 col-sm-5 col-5 pd0 m-3 text-start">
                                    <div class="btn btnbg  banbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                        Apply Now

                                        <i class="ico fa-solid fa-arrow-right"></i>

                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                    <div class="" data-aos="zoom-in" data-aos-offset="300" data-aos-easing="ease-in-sine" data-aos-delay="1500" data-aos-duration="1000"> <img src="images/bannerstudent.png" class="" alt="...">
                    </div>
                    <div class="banform">
                        <div class="form-content">
                            <p class="fw-bold form-highlighter">Set To Unlock Your Bold Side?</p>

                            <div class="form-body">

                                <p>Get In Touch </p>
                                <form id="pop-form" action="thank-you.php" name="pop-form" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('pop-form');">
                                    <div class="row">
                                        <div class="form-group col-md-12">
                                            <div class="input-group">
                                                <label class="inputial">NAME </label>

                                                <input id="enqform-fname" type="text" class="form-control" name="fname" placeholder="Enter Your Name">
                                                <input type="hidden" name="source" class="source" value="Popup Form">
                                               
                                            </div>
                                            <label for="enqform-fname" class="error"></label>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <div class="input-group">
                                                <label class="inputial">EMAIL ADDRESS </label>

                                                <input type="email" class="form-control" name="email" placeholder="Enter Your Email">
                                            </div>
                                            <label for="enqform-email" class="error"></label>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <div class="input-group">
                                                <label class="inputial">MOBILE </label>

                                                <input type="number" class="form-control" name="mobile" placeholder="Enter Your Number">
                                            </div>
                                            <label for="enqform-mobile" class="error"></label>
                                        </div>

                                        <div class="form-group col-md-12">
                                            <div class="input-group">
                                                <label class="inputial">CITY </label>

                                                <input type="text" class="form-control" name="city" placeholder="Enter Your City">
                                            </div>
                                            <label for="enqform-city" class="error"></label>
                                        </div>



                                        <div class=" col-md-12 m-0">
                                            <div class="checkboxprivcy">
                                                <input type="checkbox" id="privacy" name="privacy" value="true" checked="">

                                                <label for="privacy"> I agree to receive information</label>
                                            </div>
                                        </div>


                                        <button type="submit" class="form-btn round-btn text-center d-inline" href="#"><span>Register Now <i class="flaticon-right-arrow"></i></span></button>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="legcy">
        <div class="container">

            <div class="banner-legacy  ">
                <div class=" row mr0 about-sec align-items-center justify-content-center">

                    <div class="col-md-2 " data-aos="fade-right" data-aos-offset="100" data-aos-delay="200" data-aos-duration="1000">

                        <p class="subhead wtxt text-center">VIDYASHIP</p>
                        <h3 class="head w-clr mb-3 text-center">Legacy</h3>

                    </div>

                    <div class="col-md-2 col-6 legcy-sec" data-aos="fade-right" data-aos-offset="100" data-aos-delay="300" data-aos-duration="1000">

                        <h3>0<span class="counter">4</span></h3>
                        <p>Decades of Excellence in Education</p>
                    </div>


                    <div class="col-md-2 col-6 legcy-sec" data-aos="fade-right" data-aos-offset="100" data-aos-delay="500" data-aos-duration="1000">

                        <h3><span class="counter">300</span>+</h3>
                        <p>Faculty Members</p>
                    </div>

                    <div class="col-md-2 col-6 legcy-sec" data-aos="fade-right" data-aos-offset="100" data-aos-delay="700" data-aos-duration="1000">

                        <h3><span class="counter">10000</span>+</h3>
                        <p>Students Impacted</p>
                    </div>

                    <div class="col-md-2 col-6 legcy-sec" data-aos="fade-right" data-aos-offset="100" data-aos-delay="900" data-aos-duration="1000">

                        <h3><span class="counter">800</span>+</h3>
                        <p>Awards Won</p>
                    </div>


                </div>
            </div>
        </div>
    </section>


    <section id="overview" class="sec-pad ">

        <div class="container">

            <div class="row justify-content-center align-items-center">

                <div class="col-md-6">

                    <div class="over-wrap">

                        <p class="subhead" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1000">A
                            Program For</p>
                        <h3 class="head b-clr mb-3" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1000"> Creative
                            Innovators</h3>

                        <p>Master the art of visual storytelling at Vidyashilp University through the new-age Bachelor of Design Program with a specialized focus on Communication Design.</p>


                        <p>As we move towards 2030, the demand for creative designers is increasing at a rapid pace. Since visual content is preferred by 88% of marketers, industry reports project the global UX service market to reach USD 12500 million by 2027. </p>

                        <p>Our program offers a dynamic mix of design principles, visual communication techniques, and digital media tools to shape versatile designers capable of curating compelling narratives across various platforms. </p>

                        

                        <div class="row">

                            <div class="col-md-4 m-2 pd0">
                                <div class="btn  banbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                    Enquire Now

                                    <i class="ico fa-solid fa-arrow-right"></i>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-md-6">
                    <img src="images/overview.jpg" alt="" class="w-100 imgshdow ">
                </div>
            </div>


        </div>
    </section>


    <section id="visionery" class="sec-pad   position-relative">

        <div class="vision-wrap">

            <div class="container pt-5 pt-4 position-relative z-n2">

                <p class="subhead wtxt text-center" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1000">Program Structure That Turns You Into a</p>
                <h3 class="head w-clr mb-3 text-center" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1000">Visionary Leader</h3>


                <div class="vision-box mt-5 ">
                    <div class=" vision-nav text-center">

                        <nav class="">
                            <div class="nav nav-tabs border-0 justify-content-center" id="pills-tab" role="tablist">

                                <!-- <div class="arrowshow justify-content-center"> -->
                                <button data-aos="fade-zoom-in" data-aos-easing="ease-in-back" data-aos-delay="300" data-aos-offset="0" class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true" >Industry-Ready
                                    Minors</button>
                                <!-- </div> -->

                                <!-- <div class="arrowshow justify-content-center"> -->
                                <button data-aos="fade-zoom-in" data-aos-easing="ease-in-back" data-aos-delay="300" data-aos-offset="0" class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false" >Specilization
                                    Tracks</button>
                                <!-- </div> -->



                            </div>
                        </nav>
                    </div>

                    <div class="row mt-3 align-content-center justify-content-center">
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                <div class="swiper mySwiper gap-3">
                                <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="custcard" data-aos="fade-right" data-aos-offset="100" data-aos-delay="200" data-aos-duration="1000">
                                        <div class="vis-sec">
                                            <img src="images/gallery/vision/1.jpg" alt="" class="w-100 img-fluid">
                                            <p>Data Science</p>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="swiper-slide">
                                    <div class="custcard"  data-aos="fade-right" data-aos-offset="100" data-aos-delay="300" data-aos-duration="1000">
                                        <div class="vis-sec">
                                            <img src="images/gallery/vision/2.jpg" alt="" class="w-100 img-fluid">
                                            <p>Economics</p>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="swiper-slide">
                                    <div class="custcard" data-aos="fade-right" data-aos-offset="100" data-aos-delay="400" data-aos-duration="1000">
                                        <div class="vis-sec">
                                            <img src="images/gallery/vision/3.jpg" alt="" class="w-100 img-fluid">
                                            <p>Marketing</p>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="swiper-slide">
                                    <div class="custcard" data-aos="fade-right" data-aos-offset="100" data-aos-delay="500" data-aos-duration="1000">
                                        <div class="vis-sec">
                                            <img src="images/gallery/vision/4.jpg" alt="" class="w-100 img-fluid">
                                            <p>Psychology</p>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="swiper-slide">
                                    <div class="custcard" data-aos="fade-right" data-aos-offset="100" data-aos-delay="600" data-aos-duration="1000">
                                        <div class="vis-sec">
                                            <img src="images/gallery/vision/5.jpg" alt="" class="w-100 img-fluid">
                                            <p>Finance</p>
                                        </div>
                                    </div>
                                    </div> 
                                </div>
                                                                       
                                </div>

                            </div>
                            <!-- <div class="swiper-pagination"></div> -->

                            <div class="tab-pane" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                            <div class="d-flex gap-3 justify-content-center">
                                    <div class="custcard" data-aos="fade-right" data-aos-offset="100" data-aos-delay="200" data-aos-duration="1000">
                                        <div class="vis-sec">
                                            <img src="images/gallery/vision/ui.jpg" alt="" class="w-100 img-fluid">
                                            <p>User Experience (UX )Design</p>
                                        </div>
                                    </div>
                                    <div class="custcard"  data-aos="fade-right" data-aos-offset="100" data-aos-delay="300" data-aos-duration="1000">
                                        <div class="vis-sec">
                                            <img src="images/gallery/vision/design.jpg" alt="" class="w-100 img-fluid">
                                            <p>Design Research</p>
                                        </div>
                                    </div>
                                   
                                </div>


                            </div>
                            

                           
                        </div>
                        <div class="row justify-content-center">

                            <div class="col-md-2 d-flex pd0">
                                <div class="btn  banbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                    Enquire Now

                                    <i class="ico fa-solid fa-arrow-right"></i>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>


    <section id="eligibility" class="sec-pad ">

        <div class="cust-container">
            <div class="d-flex  align-items-end justify-content-centerf flex-md-row flex-column-reverse">
                <div class="eli-girl" data-aos="fade-up" data-aos-anchor-placement="top" data-aos-offset="300" data-aos-delay="1000" data-aos-duration="1000">
                    <img src="images/elgistud.png" class="" alt="...">
                </div>
                <div class="mb-5">
                    <img class=" elarrow" src="images/arrowani.svg" alt="">
                </div>

                <div class="mb-5">

                    <div class="flex-md-row flex-column-reverse" data-aos="fade-right" data-aos-offset="300" data-aos-delay="100" data-aos-duration="1000">
                        <div class="col-md-12">
                            <p class="elisubhead d-none d-md-block d-sm-block  text-left">Eligibility. </p>
                            <h3 class="elihead mb-3 text-left">are you in?</h3>
                            <p class="elisubhead d-md-none d-sm-none d-block  text-left">Eligibility. </p>

                        </div>
                    </div>
                    <div class="row  mb-3">
                        <div class="col-md-4 points" data-aos="fade-right" data-aos-offset="100" data-aos-delay="400" data-aos-duration="1000">
                            <div class="eligipoints position-relative">
                                <p>10+2 pass (minimum 50%) from a recognized National/State Board</p>

                            </div>

                        </div>
                        <div class="col-md-4 points" data-aos="fade-right" data-aos-offset="100" data-aos-delay="600" data-aos-duration="1000">
                            <div class="eligipoints position-relative">
                                <p>Minimum 3 subjects in the ‘A’ Level & 5 Passes in IGCSE/GCSE</p>

                            </div>
                        </div>
                        <div class="col-md-4 points" data-aos="fade-right" data-aos-offset="100" data-aos-delay="800" data-aos-duration="1000">
                            <div class="eligipoints position-relative">
                                <p>IB Diploma or IB Certificate (minimum 24 points)</p>

                            </div>
                        </div>
                    </div>
                    <div class="btn m-0 overbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                        Enquire Now

                        <i class="ico fa-solid fa-arrow-right"></i>

                    </div>
                </div>


            </div>

        </div>

    </section>


    <section id="divercity" class="sec-pad ">

        <div class="cust-container">


            <div class="d-flex  justify-content-between align-items-center">
                <div class="col-md-8">
                    <p class="subhead" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1000">
                        Scholarships (Up to 100%)</p>
                    <h3 class="head b-clr mb-3" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1000">
                        encourage diversity</h3>
                </div>
                <div class="col-md-4 text-end d-none d-md-block">
                    <div class="btn  banbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                        Enquire Now

                        <i class="ico fa-solid fa-arrow-right"></i>

                    </div>

                </div>
            </div>
            <div class="row mt-3 row-flex justify-content-center">
                <div class="col-md-3  col-6 box" data-aos="fade-right" data-aos-offset="100" data-aos-delay="200" data-aos-duration="1000">
                    <div class="diver-box position-relative">
                        <h3>Enabling Scholarship</h3>
                        <p>Meritorious student who may be challenged with financial constraints</p>

                    </div>

                </div>
                <div class="col-md-3 col-6 box" data-aos="fade-right" data-aos-offset="100" data-aos-delay="400" data-aos-duration="1000">
                    <div class="diver-box position-relative">
                        <h3>Encouragement Scholarship</h3>

                        <p>High-achieving all-rounders and differently-abled students</p>

                    </div>
                </div>
                <div class="col-md-3 col-6 box" data-aos="fade-right" data-aos-offset="100" data-aos-delay="600" data-aos-duration="1000">
                    <div class="diver-box position-relative">
                        <h3>Merit Scholarship</h3>

                        <p>To reward students with outstanding academic performance. Awarded at the time of admissions
                        </p>

                    </div>
                </div>
                <div class="col-md-3  col-6 box" data-aos="fade-right" data-aos-offset="100" data-aos-delay="800" data-aos-duration="1000">
                    <div class="diver-box position-relative">
                        <h3>Academic Performance Scholarship</h3>

                        <p>To reward students for their academic performance during the program</p>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 text-center d-block d-md-none">
            <div class="btn  banbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                Enquire Now

                <i class="ico fa-solid fa-arrow-right"></i>

            </div>

        </div>



    </section>

    <section id="ourprogram" class="sec-pad ">

        <div class="cust-container">


            <div class="d-flex justify-content-between align-items-center">
                <div class="col-md-8">
                    <p class="subhead" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1000">Insights
                        Into Key Offerings of</p>
                    <h3 class="head b-clr mb-3"> Our Program</h3>
                </div>
                <div class="col-md-4 text-end  d-none d-md-block">
                    <div class="btn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                        Enquire Now

                        <i class="ico fa-solid fa-arrow-right"></i>

                    </div>
                </div>
            </div>

            <div class="row justify-content-center align-items-center">
                <div class="col-md-6">
                    <div class="tab-content position-relative tabbg" data-aos="zoom-out" data-aos-offset="100" data-aos-delay="600" data-aos-duration="1000">
                        <div class="tab-pane active" id="Sourcing">
                            <div class="row ">
                                <div class=" col-md-12 col-sm-12 second">
                                    <img src="images/gallery/vision/1.jpg" alt="" class="w-100">
                                </div>
                            </div>

                        </div>
                        <div class="tab-pane " id="Evaluation">
                            <div class="row ">
                                <div class=" col-md-12 col-sm-12 second">
                                    <img src="images/gallery/vision/2.jpg" alt="" class="w-100">

                                </div>
                            </div>
                        </div>

                        <div class="tab-pane " id="Data">
                            <div class="row ">
                                <div class=" col-md-12 col-sm-12 second">
                                    <img src="images/gallery/vision/3.jpg" alt="" class="w-100">

                                </div>
                            </div>

                        </div>
                        <div class="tab-pane " id="Due">
                            <div class="row ">
                                <div class=" col-md-12 col-sm-12 second">
                                    <img src="images/gallery/vision/4.jpg" alt="" class="w-100">

                                </div>
                            </div>

                        </div>

                        <div class="tab-pane " id="Property">
                            <div class="row ">
                                <div class="col-md-12 col-sm-12 second">
                                    <img src="images/gallery/vision/5.jpg" alt="" class="w-100">

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-md-6">

                    <div class="over-wrap">

                        <div class=" content_name ">

                            <nav class="program">


                                <ul class="nav nav-tabs title" id="nav-tab" role="tablist">
                                    <li class="nav-item active" data-aos="zoom-in-right" data-aos-offset="100" data-aos-delay="100" data-aos-duration="1000">
                                        <a class="nav-link active" href="#Sourcing">An interdisciplinary approach to
                                            design</a>
                                    </li>
                                    <li class="nav-item" data-aos="zoom-in-right" data-aos-offset="100" data-aos-delay="200" data-aos-duration="1000">
                                        <a class="nav-link" href="#Evaluation">Exclusive focus on Communication
                                            Design</a>
                                    </li>
                                    <li class="nav-item" data-aos="zoom-in-right" data-aos-offset="100" data-aos-delay="300" data-aos-duration="1000">
                                        <a class="nav-link" href="#Data">A strong emphasis on research and academic
                                            excellence</a>
                                    </li>
                                    <li class="nav-item" data-aos="zoom-in-right" data-aos-offset="100" data-aos-delay="400" data-aos-duration="1000">
                                        <a class="nav-link" href="#Due">
                                        Portfolio development/industry internship and capstone project</a>
                                    </li>
                                    <li class="nav-item" data-aos="zoom-in-right" data-aos-offset="100" data-aos-delay="500" data-aos-duration="1000">
                                        <a class="nav-link" href="#Property">Prepares students for a career in
                                            industry/academia/research</a>
                                    </li>
                                </ul>

                            </nav>


                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="col-md-4 text-center d-block d-md-none">
            <div class="btn  banbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                Enquire Now

                <i class="ico fa-solid fa-arrow-right"></i>

            </div>

        </div>
    </section>

    <section id="infinite" class="sec-pad  position-relative">

        <div class="infinite-wrap">

            <div class="cust-container position-relative z-n2">

                <div class="d-flex  justify-content-between">
                    <div class="col-md-8" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1000">
                        <p class="subhead wtxt">The Possibilities Are </p>
                        <h3 class="head w-clr mb-3"> INFINITE</h3>
                    </div>
                    <div class="col-md-4 text-end d-none d-md-block">
                        <div class="btn  banbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            Enquire Now

                            <i class="ico fa-solid fa-arrow-right"></i>

                        </div>
                    </div>
                </div>
                <p class="wtxt">Vidyashilp University's preparation goes beyond the ordinary workforce. We equip you for
                    a greater
                    cause – to engage in diverse career avenues without being confined to a specific path. With a focus
                    on innovation, storytelling, and visual literacy, VU graduates emerge as skilled communicators
                    equipped to make meaningful contributions to various industries and society as a whole.</p>

                <div>


                    <div class="row d-none d-md-flex row-flex infibg position-relative">

                        <div class="col-md-4">
                            <div class="col-md-12 " data-aos="fade-right" data-aos-offset="100" data-aos-delay="200" data-aos-duration="1000">

                                <img src="images/gallery/infinite/1.png" alt="" class="w-100 h-100">
                            </div>

                        </div>
                        <div class="col-md-8">
                            <div class="row row-flex h-100">
                                <div class="col-md-7" data-aos="fade-right" data-aos-offset="100" data-aos-delay="400" data-aos-duration="1000">

                                    <img src="images/gallery/infinite/2.png" alt="" class="w-100 h-100">
                                </div>
                                <div class="col-md-5" data-aos="fade-right" data-aos-offset="100" data-aos-delay="600" data-aos-duration="1000">

                                    <img src="images/gallery/infinite/3.png" alt="" class="w-100 h-100">
                                </div>
                                <div class="col-md-6" data-aos="fade-right" data-aos-offset="100" data-aos-delay="800" data-aos-duration="1000">

                                    <img src="images/gallery/infinite/4.png" alt="" class="w-100 h-100">
                                </div>
                                <div class="col-md-6" data-aos="fade-right" data-aos-offset="100" data-aos-delay="1000" data-aos-duration="1000">

                                    <img src="images/gallery/infinite/5.png" alt="" class="w-100 h-100">
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="row d-flex d-md-none">

                        <div class="col-6">
                            <div class="row d-flex d-md-none row-flex h-100">

                                <div class="col-12 " data-aos="fade-right" data-aos-offset="100" data-aos-delay="200" data-aos-duration="1000">

                                    <img src="images/gallery/infinite/1.png" alt="" class="w-100 h-100">
                                </div>
                                <div class="col-12" data-aos="fade-right" data-aos-offset="100" data-aos-delay="400" data-aos-duration="1000">

                                    <img src="images/gallery/infinite/2.png" alt="" class="w-100 h-100">
                                </div>
                            </div>

                        </div>
                        <div class="col-6">
                            <div class="row row-flex">

                                <div class="col-12">

                                    <img src="images/gallery/infinite/3.png" alt="" class="w-100 h-100" data-aos="fade-right" data-aos-offset="100" data-aos-delay="600" data-aos-duration="1000">
                                </div>
                                <div class="col-12">

                                    <img src="images/gallery/infinite/4.png" alt="" class="w-100 h-100" data-aos="fade-right" data-aos-offset="100" data-aos-delay="800" data-aos-duration="1000">
                                </div>
                                <div class="col-12   ">

                                    <img src="images/gallery/infinite/5.png" alt="" class="w-100 h-100" data-aos="fade-right" data-aos-offset="100" data-aos-delay="1000" data-aos-duration="1000">
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </div>
        <div class="col-md-4 text-center d-block d-md-none">
            <div class="btn  banbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                Enquire Now

                <i class="ico fa-solid fa-arrow-right"></i>

            </div>

        </div>
    </section>


    <section id="leader" class="sec-pad   position-relative">


        <div class="cust-container position-relative z-n2">


            <p class="subhead  text-center" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1000">Where
                One Leader</p>
            <h3 class="head b-clr mb-3 text-center" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1000">Creates Another</h3>


            <div class=" mt-5" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">


                <div class="row mt-5 align-content-center justify-content-center">
                    <div class="swiper createSwiper">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/1.png" alt="" class="w-100">
                                    <h3>Ms. Kavita Singh Kale</h3>
                                    <p>Associate Professor School of Liberal Arts and Design Studies</p>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/2.png" alt="" class="w-100">
                                    <h3>Dr. Setu Havanur</h3>
                                    <p>Assistant Professor School of Liberal Arts and Design Studies</p>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/3.png" alt="" class="w-100">
                                    <h3>Dr. Ranjana Raghunathan </h3>
                                    <p>Associate Professor School of Liberal Arts and Design Studies</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/rsz_copy_of_radhika_lobo.jpg" alt="" class="w-100">
                                    <h3>Prof. Radhika Lobo </h3>
                                    <p>Program Chair, B.A (Hons)</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/ProfSmithaRao.jpg" alt="" class="w-100">
                                    <h3>Prof. Smitha Rao </h3>
                                    <p>Program Chair, B.Tech (Hons) - Computer</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Umesh-new.jpg" alt="" class="w-100">
                                    <h3>Prof. Umesh S. Mahtani </h3>
                                    <p>Program Chair, Bachelor of Management Studies</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/RP-Suresh-scaled-2.jpg" alt="" class="w-100">
                                    <h3>Prof. R.P. Suresh </h3>
                                    <p>Professor of Practice, School of
Computational and Data Sciences &
School of Business Studies</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/reDC-Kiran.jpg" alt="" class="w-100">
                                    <h3>Dr. D.C. Kiran </h3>
                                    <p>Associate Professor, School of
Computational and Data Sciences</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Picture2.png" alt="" class="w-100">
                                    <h3>Dr. Mahendra B M </h3>
                                    <p>Associate Professor, School of
Computational and Data Sciences</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Mehala.jpg" alt="" class="w-100">
                                    <h3>Dr. N. Mehala </h3>
                                    <p>Associate Professor, School of Computational and Data Sciences</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Images-01.jpg" alt="" class="w-100">
                                    <h3>Dr. Amrita Ghatak </h3>
                                    <p>Associate Professor of Economics, School of Liberal Arts and Design Studies</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/bijil_prakash.jpg" alt="" class="w-100">
                                    <h3>Dr. Bijil Prakash </h3>
                                    <p>Director of Campus Life,
Office of Student Affairs
Assistant Professor, School of
Computational and Data Sciences</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Dr.-Anupama-1-re.jpg" alt="" class="w-100">
                                    <h3>Dr. Anupama A.V. </h3>
                                    <p>Assistant Professor, School of Computational
and Data Sciences</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/neha_khurana_Highres.jpg" alt="" class="w-100">
                                    <h3>Dr. Neha Khurana </h3>
                                    <p>Assistant Professor, School of Legal Studies
and Governance & School of Liberal Arts and Design Studies</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Kavya.png" alt="" class="w-100">
                                    <h3>Ms. Kavya Salim</h3>
                                    <p>Assistant Professor, School of Legal Studies and Governance</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Aravindan2.jpeg" alt="" class="w-100">
                                    <h3>Mr. Aravindan Anandan</h3>
                                    <p>Assistant Professor, School of Legal Studies and Governance</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Images-05-New.jpg" alt="" class="w-100">
                                    <h3>Dr. Priyambada Tripathi</h3>
                                    <p>Assistant Professor, School of Computational and Data Sciences</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Images-02.jpg" alt="" class="w-100">
                                    <h3>Dr. Jobeth Ann Warjri</h3>
                                    <p>Assistant Professor, School of Liberal Arts and Design Studies,</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Images-04.jpg" alt="" class="w-100">
                                    <h3>Dr. Ninad Patwardhan</h3>
                                    <p>Assistant Professor, School of Liberal Arts and Design Studies,</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Images-03.jpg" alt="" class="w-100">
                                    <h3>Dr. Tania Islam</h3>
                                    <p>Assistant Professor, School of Liberal Arts and Design Studies</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/AMLANIKA_PHOTO.png" alt="" class="w-100">
                                    <h3>Ms. Amlanika Bora</h3>
                                    <p>Assistant Professor, School of Legal Studies and Governance</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Spatica-Ramanujam.jpg" alt="" class="w-100">
                                    <h3>Ms. Spatica Ramanujam</h3>
                                    <p>Adjunct Faculty, School of Liberal Arts and Design Studies</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Prabhakaran-Balasubramanian-new.png" alt="" class="w-100">
                                    <h3>Mr. Prabhakaran Balasubramanian</h3>
                                    <p>Adjunct Professor, School of
Business Studies</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Soorya_Adjunct_250x250.jpg" alt="" class="w-100">
                                    <h3>Dr. Soorya Menon</h3>
                                    <p>Adjunct Faculty, School of Liberal Arts and Design Studies</p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="lead-sec">
                                    <img src="images/gallery/leader/Archana-Kumar.jpg" alt="" class="w-100">
                                    <h3>Ms. Archana Kumar</h3>
                                    <p>Adjunct Faculty, School of Liberal Arts and Design Studies</p>
                                </div>
                            </div>


                        </div>
                    </div>


                </div>

            </div>
        </div>

    </section>

    <section id="student" class="sec-pad  position-relative">


        <div class="cust-container position-relative z-n2">

            <p class="subhead  text-center" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1000">
                Engaging student life to bring out</p>
            <h3 class="head b-clr mb-3 text-center" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1000">Your Inner Self</h3>




            <div class=" mt-5 " data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                <div class="row mt-5 align-content-center justify-content-center">
                    <div class="swiper createSwiper">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="self-sec">
                                    <img src="images/gallery/self/2.png" alt="" class="w-100 imgshdow">
                                    <p>Equestrian Sports</p>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="self-sec">
                                    <img src="images/gallery/self/1.png" alt="" class="w-100 imgshdow">
                                    <p>Art And Culture </p>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="self-sec">
                                    <img src="images/gallery/self/3.png" alt="" class="w-100 imgshdow">
                                    <p>Student Activity</p>
                                </div>
                            </div>


                        </div>
                    </div>


                </div>
            </div>
        </div>

    </section>

    <section id="boldvisusl" class=" sec-pad  position-relative">

        <div class="bold-wrap">

            <div class="cust-container  position-relative z-n2">

                <div class="d-flex  justify-content-between align-items-center  aos-init aos-animate" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                    <div class="col-md-8">
                        <p class="subhead wtxt">Evolve into a</p>
                        <h3 class="head w-clr mb-3"> bold Leader</h3>
                    </div>
                    <div class="col-md-4 text-end d-none d-md-block">
                        <div class="btn  banbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            Enquire Now

                            <i class="ico fa-solid fa-arrow-right"></i>

                        </div>
                    </div>
                </div>
                <p class="wtxt">Vidyashilp University stands as a beacon of academic excellence, innovation, and
                    holistic learning in the educational landscape. Committed to nurturing well-rounded individuals, the
                    University provides a diverse range of programs across various disciplines. At VU, we always pave
                    the path less taken so our students become more than just graduates. Leverage the unparalleled
                    advantages of studying at Vidyashilp University, where we redefine the boundaries of education to
                    offer you a disruptive learning experience.</p>

                <div>

                    <div class="d-none d-md-block boldbg " data-aos="fade-down" data-aos-delay="1000" data-aos-duration="1500">
                        <div class="row  row-flex h-100 boldbox1">

                            <div class="col-md-3" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">
                                <div class="  bgred h-100">
                                    <div class="visul-box position-relative">
                                        <h3>Master the Art of Research</h3>
                                        <p>Craft Original Content for Diverse Audiences</p>

                                    </div>

                                </div>

                            </div>
                            <div class="col-md-9" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">

                                <img src="images/gallery/bold/1.png" alt="" class="w-100">

                            </div>
                        </div>
                        <div class="row row-flex ">
                            <div class="col-md-4">
                                <div class="row row-flex ">
                                    <div class="col-md-12" data-aos="fade-right" data-aos-delay="500" data-aos-duration="1500">
                                        <img src="images/gallery/bold/2.png" alt="" class="w-100">
                                    </div>
                                    <div class="col-md-12" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">

                                        <div class=" box bgred ">
                                            <div class="visul-box position-relative">
                                                <h3>Emerge as a Community Catalyst</h3>
                                                <p>Engage and Collaborate for Collective Progress</p>

                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="col-md-8">
                                <div class="row row-flex h-100 ">
                                    <div class="col-md-12" data-aos="fade-right" data-aos-delay="500" data-aos-duration="1500">
                                        <div class=" box bgblue ">
                                            <div class="visul-box position-relative">
                                                <h3>Go Beyond Design</h3>
                                                <p>Cultivate an Ecological, Ethical, and Conscientious Perspective</p>

                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-12" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">

                                        <img src="images/gallery/bold/3.png" alt="" class="w-100 h-100">
                                    </div>
                                </div>

                            </div>


                        </div>
                        <div class="row row-flex h-100">
                            <div class="col-md-6 " data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">

                                <img src="images/gallery/bold/4.png" alt="" class="w-100">

                            </div>
                            <div class="col-md-6" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">
                                <div class=" box bgblue h-100">
                                    <div class="visul-box position-relative">
                                        <h3>Gain Hands-On Experience</h3>
                                        <p>Build Your Portfolio Through Integrative Projects Each Term</p>

                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="d-block d-md-none boldbg">
                        <div class="row  row-flex h-100 boldbox1">
                            <div class="col-6" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">
                                <div class="bgred h-100">
                                    <div class="visul-box position-relative">
                                        <h3>Master the Art of Research</h3>
                                        <p>Craft Original Content for Diverse Audiences</p>

                                    </div>

                                </div>

                            </div>
                            <div class="col-6" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">

                                <img src="images/gallery/bold/m1.png" alt="" class="w-100 h-100">

                            </div>
                        </div>
                        <div class="row row-flex ">
                            <div class="col-6">
                                <div class="row row-flex ">
                                    <div class="col-12" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">
                                        <img src="images/gallery/bold/m2.png" alt="" class="w-100 ">
                                    </div>
                                    <div class="col-12" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">
                                        <div class=" box bgred">
                                            <div class="visul-box position-relative">
                                                <h3>Go Beyond Design</h3>
                                                <p>Cultivate an Ecological, Ethical, and Conscientious Perspective</p>

                                            </div>

                                        </div>


                                    </div>

                                </div>
                            </div>

                            <div class="col-6">
                                <div class="row row-flex h-100 ">
                                    <div class="col-12" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">
                                        <div class=" box bgblue ">
                                            <div class="visul-box position-relative">
                                                <h3>Emerge as a Community Catalyst</h3>
                                                <p>Engage and Collaborate for Collective Progress</p>

                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-12" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">

                                        <img src="images/gallery/bold/m3.png" alt="" class="w-100 h-100">
                                    </div>
                                </div>

                            </div>


                        </div>
                        <div class="row row-flex h-100">
                            <div class="col-6" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">

                                <img src="images/gallery/bold/m4.png" alt="" class="w-100 h-100">

                            </div>
                            <div class="col-6" data-aos="fade-right" data-aos-delay="1000" data-aos-duration="1500">
                                <div class=" box bgblue h-100">
                                    <div class="visul-box position-relative">
                                        <h3>Gain Hands-On Experience</h3>
                                        <p>Build Your Portfolio Through Integrative Projects Each Term</p>

                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 text-center d-block d-md-none">
            <div class="btn  banbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                Enquire Now

                <i class="ico fa-solid fa-arrow-right"></i>

            </div>

        </div>
    </section>


    <section id="accrediation" class="sec-pad mt-5">

        <div class="cust-container">


            <div class="accr-img">

                <div class="accrhead" data-aos="fade-down" data-aos-delay="500" data-aos-duration="1000">
                    <p class="subhead wtxt  text-center">Vidyashilp University </p>
                    <h3 class="head mb-3 w-clr text-center">Accreditations</h3>
                </div>
                <div class="row mt-5 align-content-center justify-content-center ">
                    <div class="col-md-4 mt-2 arrpoints" data-aos="fade-down" data-aos-delay="800" data-aos-duration="1000">
                        <div class="arraward position-relative ">
                            <img src="images/gallery/award/1.png" alt="" class=" d-block m-auto">
                            <p class="text-center">University Grants <br>Commission</p>

                        </div>

                    </div>
                    <div class="col-md-4 mt-2 arrpoints" data-aos="fade-down" data-aos-delay="1000" data-aos-duration="1000">
                        <div class="arraward position-relative">
                            <img src="images/gallery/award/2.png" alt="" class=" d-block m-auto">
                            <p class="text-center">Association of<br> Indian Universities</p>

                        </div>

                    </div>

                </div>
            </div>



        </div>

    </section>

    <section id="learning" class=" position-relative">

        <div class="learn-wrap">

            <div class="cust-container  position-relative z-n2">

                <div class="d-flex  justify-content-between align-items-center">
                    <div class="col-md-8" data-aos="fade-down" data-aos-delay="1000" data-aos-duration="1500">
                        <p class="subhead ">Integrative Pedagogy to Ensure a disruptive</p>
                        <h3 class="head b-clr mb-3"> Learning Experience </h3>
                    </div>
                    <div class="col-md-4 text-end d-none d-md-block">
                        <div class="btn  banbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            Enquire Now

                            <i class="ico fa-solid fa-arrow-right"></i>

                        </div>
                    </div>
                </div>
                <p class="">Vidyashilp University's curriculum and pedagogical approach are designed to help
                    students solve problems in an interdisciplinary way. It helps students align their thinking to solve
                    real-world problems.</p>

                <div class="learngbg position-relative">


                    <div class="row mt-3 align-content-center justify-content-center">


                        <div class="swiper learnSwiper">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide" data-aos="fade-right" data-aos-offset="100" data-aos-delay="200" data-aos-duration="1000">
                                    <div class="exp-sec">
                                        <img src="images/gallery/exp/1.png" alt="" class="w-100">
                                        <p>Experiential challenge-based learning</p>
                                    </div>
                                </div>
                                <div class="swiper-slide" data-aos="fade-right" data-aos-offset="100" data-aos-delay="300" data-aos-duration="1000">
                                    <div class="exp-sec">
                                        <img src="images/gallery/exp/2.png" alt="" class="w-100">
                                        <p>Interdisciplinary problem-solving exposure</p>
                                    </div>
                                </div>
                                <div class="swiper-slide" data-aos="fade-right" data-aos-offset="100" data-aos-delay="400" data-aos-duration="1000">
                                    <div class="exp-sec">
                                        <img src="images/gallery/exp/3.png" alt="" class="w-100">
                                        <p>Technology-enhanced learning
                                            for life</p>
                                    </div>
                                </div>
                                <div class="swiper-slide" data-aos="fade-right" data-aos-offset="100" data-aos-delay="500" data-aos-duration="1000">
                                    <div class="exp-sec">
                                        <img src="images/gallery/exp/4.png" alt="" class="w-100">
                                        <p>Center for learning science and technologies</p>
                                    </div>
                                </div>


                            </div>
                            <!-- <div class="swiper-pagination"></div> -->
                        </div>

                        <!-- 

                        <div class="col-md-3">
                            <div class="exp-sec">
                                <img src="images/gallery/exp/1.png" alt="" class="w-100">
                                <p>Experiential challenge-based learning</p>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="exp-sec">
                                <img src="images/gallery/exp/2.png" alt="" class="w-100">
                                <p>Interdisciplinary problem-solving exposure</p>
                            </div>
                        </div>
                        <div class="col-md-3 ">
                            <div class="exp-sec">
                                <img src="images/gallery/exp/3.png" alt="" class="w-100">
                                <p>Technology-enhanced learning
                                    for life</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="exp-sec">
                                <img src="images/gallery/exp/4.png" alt="" class="w-100">
                                <p>Centre for learning science
                                    and technologies</p>
                            </div>
                        </div> -->


                    </div>
                </div>
            </div>
            <div class="col-md-4 text-center d-block d-md-none">
                <div class="btn  banbtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                    Enquire Now

                    <i class="ico fa-solid fa-arrow-right"></i>

                </div>

            </div>
        </div>


    </section>


    <section id="stduents" class="sec-pad  position-relative">


        <div class="container-fluid  position-relative z-n2">
            <div class="row justify-content-center align-items-center">

                <div class="offset-md-2 col-md-5 " data-aos="fade-right" data-aos-delay="500" data-aos-duration="1000">
                    <div class=" d-block m-auto stud-sec studbg position-relative">
                        <p class="feed"><span>&#x201D; </span>Student Testimonials</p>
                        <p class="subhead ">What Our</p>
                        <h3 class="head b-clr mb-3 ">Students Say?</h3>

                        <!-- <div class="row align-items-center justify-content-center   ">
                            <div class="col-4">
                                <h3 class="count">99%</h3>
                            </div>
                            <div class="col-8">
                                <p class="sttxt">Student's have completed the programs successfully.
                                </p>
                            </div>
                        </div> -->
                    </div>
                </div>



                <div class="col-md-7 pd0">
                    <div class="stud-say vidbg position-relative">
                        <div class="col-md-7" data-aos="zoom-out" data-aos-delay="500" data-aos-duration="1000">
                            <div class="">
                                <img src="images/gallery/studsay/1.png" alt="" class="w-100">
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>


    </section>

    <footer>

        <div class="footer">
            <p class="text-center">Copyright © 2024 Vidyashilp University. All rights reserved</p>
        </div>
    </footer>
    <!-- Modal -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-body">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>

                    <div class="banform">
                        <div class="form-content">
                            <p class="fw-bold form-highlighter">Set To Unlock Your Bold Side?</p>

                            <div class="form-body">

                                <p>Get In Touch </p>
                                <form id="enq-form" action="thank-you.php" name="enq-form" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('enq-form');">
                                    <div class="row">
                                        <div class="form-group col-md-12">
                                            <div class="input-group">
                                                <label class="inputial">NAME </label>

                                                <input id="enqform-fname" type="text" class="form-control" name="fname" placeholder="Enter Your Name">
                                                <input type="hidden" name="source" class="source" value="Download Brochure">
                                                <input type="hidden" id="enq-enqproject" name="enqproject" value="">
                                            </div>
                                            <label for="enqform-fname" class="error"></label>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <div class="input-group">
                                                <label class="inputial">EMAIL ADDRESS </label>

                                                <input type="email" class="form-control" name="email" placeholder="Enter Your Email">
                                            </div>
                                            <label for="enqform-email" class="error"></label>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <div class="input-group">
                                                <label class="inputial">MOBILE </label>

                                                <input type="number" class="form-control" name="mobile" placeholder="Enter Your Number">
                                            </div>
                                            <label for="enqform-mobile" class="error"></label>
                                        </div>

                                        <div class="form-group col-md-12">
                                            <div class="input-group">
                                                <label class="inputial">CITY </label>

                                                <input type="text" class="form-control" name="city" placeholder="Enter Your City">
                                            </div>
                                            <label for="enqform-city" class="error"></label>
                                        </div>



                                        <div class=" col-md-12 m-0">
                                            <div class="checkboxprivcy">
                                                <input type="checkbox" id="privacy" name="privacy" value="true" checked="">

                                                <label for="privacy"> I agree to receive information</label>
                                            </div>
                                        </div>


                                        <button type="submit" class="form-btn round-btn text-center d-inline" href="#"><span>Register Now <i class="flaticon-right-arrow"></i></span></button>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- <script src="js/jquery.min.js" async defer></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="js/boottsrap.js"></script>
    <script src="js/mobilevalidate.js"></script>
    <script src="js/jquery.validate.js"></script>
    <script src="js/cookie.js"></script>

    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/michalsnik/aos@2.0.4/dist/aos.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>



    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>



    <script src="https://cdn.jsdelivr.net/jquery.counterup/1.0/jquery.counterup.min.js"></script>

    <script>
    Delete_Cookie('formfilled');
</script>

<script type="text/javascript">
    function save_landing_pageinfo(elm) {
        jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', true);
        setTimeout(function () {
            jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', false);
        }, 5000);
        var name = jQuery('#' + elm + ' input[name="fname"]').val();
        var mobileno = jQuery('#' + elm + ' input[name="mobile"]').val();
        var emailid = jQuery('#' + elm + ' input[name="email"]').val();
        var message = jQuery('#' + elm + ' textarea[name="message"]').val();
        var fsource = jQuery('#' + elm + ' input[name="source"]').val();
        var current_url = location.hostname;

        if (name == "") {
            //alert("Please Enter Your Name");
            return false;
        }
        mobileno = mobileno.replace(/[^0-9]/g, '');
        if (mobileno.length != 10) {
            //alert("Please Enter 10 Digit Mobile Number");
            return false;
        }
        if (elm == 'main-popup') {
            emailid = "";
        } else {
            var atpos = emailid.indexOf("@");
            var dotpos = emailid.lastIndexOf(".");
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= emailid.length) {
                return false;
            }
        }
        if (message == undefined) {
            message = "";
        }
        if (name != "" && mobileno != "") {
            $("#pageloader").fadeIn();
            if (elm == 'brochure-form') {
                document.getElementById('download-file').click();
            }
            return true;
        }
        return false;
    }

    function submitForm(elm) {
        document.createElement('form').submit.call(document.getElementById(elm));
    }
</script>
    <script>
        $('.counter').counterUp({
            delay: 10,
            time: 2000
        });
        $('.counter').addClass('animated fadeInDownBig');
        $('h3').addClass('animated fadeIn');
    </script>

    <script>
        AOS.init({
            duration: 1000
        });
    </script>

    <script>
        // Tab-Pane change function
        var tabChange = function() {
            var tabs = $(".program .nav-tabs > li");
            var active = tabs.filter(".active").removeClass("active");
            var next = active.next("li").length ?
                active.next("li") :
                tabs.filter(":first-child")
            // Bootsrap tab show, para ativar a tab
            next.addClass("active").find("a").tab("show")
        };
        // Tab Cycle function
        var tabCycle = setInterval(tabChange, 6000);
        // Tab click event handler
        $(function() {
            $(".program .nav-tabs a").click(function(e) {
                e.preventDefault();
                $(".program .nav-tabs .active").removeClass("active")
                // Stop the cycle
                clearInterval(tabCycle);
                // Show the clicked tabs associated tab-pane
                $(this).tab("show");
                $(this).parent().addClass("active");
                // Start the cycle again in a predefined amount of time
                setTimeout(function() {
                    tabCycle = setInterval(tabChange, 6000);
                }, 6000);
            });
        });
    </script>
    <script>
        // $(".program .nav-link").hover(function() {
        //     $(this).tab('show');
        // });
        $('.navbar-nav>li>a').on('click', function() {
            $('.navbar-collapse').collapse('hide');
        });
    </script>


    <!-- Initialize Swiper -->
    <script>
        var swiper = new Swiper(".mySwiper", {
            slidesPerView: "auto",
            spaceBetween: 30,
            dots: false,
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            breakpoints: {
                1920: {
                    slidesPerView: 5,
                    spaceBetween: 30
                },
                1028: {
                    slidesPerView: 5,
                    spaceBetween: 30
                },
                480: {
                    slidesPerView: 1,
                    spaceBetween: 10
                }
            },
        });

        var swiper = new Swiper(".learnSwiper", {
            slidesPerView: "auto",
            spaceBetween: 30,
            dots: false,
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            breakpoints: {
                1920: {
                    slidesPerView: 4,
                    spaceBetween: 30
                },
                1028: {
                    slidesPerView: 4,
                    spaceBetween: 30
                },
                480: {
                    slidesPerView: 1,
                    spaceBetween: 10
                }
            },
        });


        var swiper = new Swiper(".createSwiper", {
            slidesPerView: "auto",
            spaceBetween: 30,
            dots: false,
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            breakpoints: {
                1920: {
                    slidesPerView: 3,
                    spaceBetween: 30
                },
                1028: {
                    slidesPerView: 3,
                    spaceBetween: 30
                },
                480: {
                    slidesPerView: 1,
                    spaceBetween: 10
                }
            },
        });
    </script>



</body>

</html>