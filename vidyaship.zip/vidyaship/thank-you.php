<?php

//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

$request = $_SERVER['REQUEST_METHOD'];
$name = $_REQUEST['fname'];
$mobile = $_REQUEST['mobile'];
$email = $_REQUEST['email'];


if ($request !== 'POST') {
    http_response_code(405);
    echo 'Method Not Allowed';
    echo '</br>';
    echo "<a href='/'>Go Back</a>";
    die;
}

if ($_REQUEST['mobile'] == '') {
    echo 'Please enter valid mobile number';
    echo '</br>';
    echo "<a href='/'>Go Back</a>";
    die;
}
if (ctype_alpha(str_replace(' ', '', $name)) === false) {
    echo 'Please enter valid Name';
    echo '</br>';
    echo "<a href='/'>Go Back</a>";
    die;
}


if (strlen($_REQUEST['mobile']) !== 10) {
    echo 'Please enter valid mobile number';
    echo '</br>';
    echo "<a href='/'>Go Back</a>";
    die;
}
if(!preg_match('/^[6789]\d{9}$/', $_POST['mobile']))
    {
        echo 'Please enter valid mobile number';
        echo '</br>';
        echo "<a href='/'>Go Back</a>";
        die;
    }
    $regex = '/^[A-Za-z][a-z\s]*$/';

    if(!preg_match($regex, $name)) {
       echo 'Please enter valid Name';
        echo '</br>';
        echo "<a href='/'>Go Back</a>";
        die;
    }

    $emailregex = '/^(jayesh04|jay06|jay04|jayesh06)@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/';

    if(preg_match($emailregex, $email)) {
        echo 'Please enter valid Name';
         echo '</br>';
         echo "<a href='/'>Go Back</a>";
         die;
     }

session_start();
require_once 'send_leads.php';


$postData = new PostData();

if ((!isset($_COOKIE['formfilled'])) && isset($_REQUEST['mobile'])) {

    $mailsent = $postData->callback();
    setcookie('formfilled', 'yes');
    setcookie('checkduplicate', $_REQUEST['mobile'], time() + (86400 * 7));

} else {
    $mailsent = false;
}
?>
<!DOCTYPE html>
<html>
<head>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P3ZBKWK9');</script>

<!-- End Google Tag Manager -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Vidyaship | Thank You</title>
    <meta name="keywords" content="">
    <meta name="">
    <link rel="icon" href="images/fav-icon.png" type="image/png" sizes="16x16">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,600,800,900" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
          integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css?v=1.0" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/form.css">
</head>

<body>

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P3ZBKWK9"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<!-- End Google Tag Manager (noscript) -->

<!-- <img class="thank-banner" src="images/thankbanner.jpg"> -->
<section class="sec-thank">
    <div class="container">

            <?php
            if (!$mailsent) {
                ?>

                <span class="msgicon" aria-hidden="true"><i class="fa fa-times"
                                                            aria-hidden="true"></i></span>
                <h2 class="oops">Oops!</h2>
                <h3 class="oops-subtitle" style="text-align:center;">
                    Sorry for the inconvenience! Mail could not be sent.<br/>
                    Please try again after some time.
                </h3>
                <a href="index.php" style="text-decoration: none;"><h2 class="go-home"><span
                            class="" aria-hidden="true"><i class="fa fa-arrow-left"
                                                           aria-hidden="true"></i></span> GO
                        BACK TO HOME</h2></a>
                <?php
            } else {
                ?>
                <!-- <span class="msgicon" aria-hidden="true"><i class="fa fa-check"
                                                            aria-hidden="true"></i></span> -->
                <div class="foot-im">
                    <img src="images/logo.png"/> 
                </div>
                                                          
                <h2 class="oops">You're all set!</h2>
                <h3 class="oops-greet" style="text-align:center;">Greetings from Vidyaship  </h3>
                <h3 class="oops-subtitle" style="text-align:center;">
                    Thank you for expressing interest on our website.<br/>
                    Our expert will get in touch with you shortly.
                </h3>
                <a href="index.php" style="text-decoration: none;"><h2 class="go-home"><span
                            class="" aria-hidden="true"><i class="fa fa-arrow-left"
                                                           aria-hidden="true"></i></span> GO
                        BACK TO HOME</h2></a>

                <?php
            }
            ?>




    </div>
</section>


<footer class="footer">
    <div class="container">
    <p>© 2024 Vidyaship . All Rights Reserved</p>
                <!-- <p>Digital Partner: <a href="realatte.com"> Realatte</a></p> -->
    </div>
</footer>






<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>

<script src="js/jquery.validate.js"></script>
<script src="js/mobilevalidate.js"></script>
<script src="js/cookie.js"></script>
<script src="js/popout.js"></script>





</body>
</html>