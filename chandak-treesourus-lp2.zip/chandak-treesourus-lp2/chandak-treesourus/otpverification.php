<?php



$utm_source = $_COOKIE['utm_source'];
$utm_campaign = $_COOKIE['utm_campaign'];
$utm_term = $_COOKIE['utm_term'];
$utm_placement = $_COOKIE['utm_placement'];
$utm_device = $_COOKIE['utm_device'];

$cookienum = $_COOKIE['cookienum'];
$source = $_POST['source'];


$fname = $_REQUEST['fname'];
$lname = $_REQUEST['lname'];
$email = $_REQUEST['email'];
$mobile = str_replace(' ','',$_REQUEST['mobile']);

$message ="Non Verified";


$request = $_SERVER['REQUEST_METHOD'];
if ($request !== 'POST') {
    http_response_code(405);
    echo 'Method Not Allowed';
    echo '</br>';
    echo "<a href='index.php'>Go Back</a>";
    die;
}

if(ctype_alpha(str_replace(' ', '', $fname)) === false)
    {
      die;
    }

if(!preg_match('/^[0-9]+$/', $_POST['mobile']))
    {
      die;
    }

if(empty($fname))
{
    die;
} 

    if(empty($mobile))
{
    die;
} 

/***********integration    ********* */

        // Google Sheet Interation------------------
        $postFields = "entry.449648499=" . $fname;
        $postFields .= "&entry.1379833540=" . $email;
        $postFields .= "&entry.758332158=" . $mobile;
        $postFields .= "&entry.1900106466=" . $message;
        $postFields .= "&entry.1693361781=" . $source;

        $postFields .= '&entry.1830911442=' . urlencode($utm_campaign);
        $postFields .= '&entry.939490048=' . urlencode($utm_source);
        $postFields .= '&entry.729166844=' . urlencode($utm_term);
        $postFields .= '&entry.839903606=' . urlencode($utm_placement);
        $postFields .= '&entry.2003337495=' . urlencode($utm_device);

        $ch1 = curl_init();
        curl_setopt($ch1, CURLOPT_URL, "https://docs.google.com/forms/u/1/d/e/1FAIpQLSe8SbwOF9OsdvzgxgPAOSfMr-ml5WL-ib-hyFQhvsyDTdEMVA/formResponse");
        curl_setopt($ch1, CURLOPT_POST, 1);
        curl_setopt($ch1, CURLOPT_POSTFIELDS, $postFields);
        curl_setopt($ch1, CURLOPT_HEADER, 0);
        curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);
        $result1 = curl_exec($ch1);
        //print_r($result1);



function generateNumericOTP($n)
{

    $generator = "1357902468";

    $result = "";

    for ($i = 1; $i <= $n; $i++) {
        $result .= substr($generator, (rand() % (strlen($generator))), 1);
    }

    return $result;
}

// Main program
$n = 6;
// print_r(generateNumericOTP($n));
 $otp = (generateNumericOTP($n));  #REMOVED BY CIJAGANI
 setcookie('projectscode', $otp); #REMOVED BY CIJAGANI

// require_once 'class/clientemail-otp.php';

$otpmsg = "Hi, you requested OTP at Chandak Group Site https://chandak-treesourus.com/, your OTP is ". $otp ."";
// $otpmsg = "Hey there! Please use this OTP: $otpnumber to book your Virtual appointment on SunteckAER. Do not share your OTP with anyone.";

 ##OTP##
// $url = "https://japi.instaalerts.zone/httpapi/QueryStringReceiver?ver=1.0&key=CDDTcyc1y6IjhhXzlKj2TQ==&encrpt=0&dest=91" .$mobile. "&text=".urlencode($otpmsg)."&route=1";
$url = "https://japi.instaalerts.zone/httpapi/QueryStringReceiver?ver=1.0&key=CDDTcyc1y6IjhhXzlKj2TQ==&encrpt=0&dest=91".$mobile."&send=CDKRLS&dlt_entity_id=1001550840000010997&text=".urlencode($otpmsg);
$ch1 = curl_init();
curl_setopt($ch1, CURLOPT_URL,$url);
curl_setopt($ch1, CURLOPT_HEADER, 0);
curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);


$result3 = curl_exec($ch1);
// var_dump($result3,$url);
// die();





?>


<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Google Tag Manager -->
    <script>
    (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-WS9TJHC');
    </script>
    <!-- End Google Tag Manager -->
    <meta charset="utf-8">

    <!--====== Title ======-->
    <title>Thank You | Codename Nostalgia</title>

    <meta name="description"
        content="Chandak Greenairy flats in Borivali by Chandak Group. A design that epitomizes elegance, comfort and greenary. Located near National Park Borivali (E) Mumbai.">

    <meta name="keywords"
        content="new residential projects in borivali east, 2 bhk in borivali east, 1 bhk in borivali east, residential property for sale in borivali east, luxurious 2 BHK apartments at borivali east, 2 bhk near national park, jodi flats in borivali east, borivali east flats for sale">


    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.webp" type="image/png">

    <!--====== Animate CSS ======-->
    <link rel="stylesheet" href="assets/css/animate.css">

    <!--====== Magnific Popup CSS ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!--====== Slick CSS ======-->
    <link rel="stylesheet" href="assets/css/slick.css">

    <!--====== Line Icons CSS ======-->
    <link rel="stylesheet" href="assets/css/LineIcons.css">

    <!--====== Font Awesome CSS ======-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!--====== Bootstrap CSS ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lity/2.4.1/lity.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.css" />

    <!--====== Default CSS ======-->
    <link rel="stylesheet" href="assets/css/default.css">

    <!--====== Style CSS ======-->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">

    <!-- Toastr CSS -->
    <link rel="stylesheet" href="assets/css/toastr.min.css">
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WS9TJHC" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <!--====== HEADER PART START ======-->

    <header class="header-area">
        <div class="navbar-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg">
                            <a class="navbar-brand" href="index.php">
                                <img src="assets/images/logo.webp" class="logo-1" alt="Logo">
                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul class="navbar-nav m-auto">
                                    <li class="nav-item">
                                        <a class="page-scroll active" href="#overview">OVERVIEW</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="page-scroll " href="#location">LOCATION</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="page-scroll " href="#config">CONFIGURATIONS</a>
                                    </li>

                                    <!-- <li class="nav-item">
                                        <a class="page-scroll " href="#amenities">Amenities</a>
                                    </li> -->

                                    <li class="nav-item">
                                        <a class="page-scroll " href="#highlights">PROJECT HIGHLIGHTS</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="page-scroll " href="#gallery">GALLERY</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="page-scroll" href="#about">SHOW FLAT</a>
                                    </li>

                                </ul>
                            </div> <!-- navbar collapse -->

                            <div class="navbar-btn d-sm-inline-block">
                                <a class="navbar-brand-2" href="index.php">
                                    <img src="assets/images/chandak-logo.webp" class="logo-2" alt="Logo">
                                    <!--                                    <img src="assets/images/logo-2.webp" class="logo-2" alt="Logo">-->
                                </a>
                            </div>
                        </nav> <!-- navbar -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- navbar area -->


    </header>

    <!--====== HEADER PART ENDS ======-->



    <section id="sp-main-body" style="background: url(assets/images/Amenities-Bg.webp);padding: 100px 0px;">
        <div class="container">
            <div class="row">
                <div id="sp-component" class="col-md-12 m-auto">
                    <div class="w-50 m-auto">
                        <img src="assets/images/logo.webp" alt=""
                            style=" display: block; margin: 15px auto; width: 100px;">


                        <div class="otp-formwrap text-center">
                            <h3 class="text-white">One Time Password</h3>
                            <p style="text-white: center;">Please enter the OTP sent on mobile.</p>
                            <form id="otp-form" action="thank-you.php" name="otp-form" method="POST"
                                onsubmit="return otpverify('otp-form');">
                                <input type="hidden" name="fname" value="<?php echo "$fname"; ?>">
                                <input type="hidden" name="mobile" value="<?php echo "$mobile" ?>">
                                <input type="hidden" name="email" value="<?php echo "$email" ?>">
                                <input type="hidden" name="source" value="<?php echo "$source" ?>">


                                <div class="form-group col-md-12 pd">
                                    <div class="input-group">
                                        <input type="number" class="form-control form-group" placeholder="Enter OTP*"
                                            name="otp" required>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <button type="submit" class="btn btn-default popup-btn"
                                            value="proceed">SUBMIT</button>
                                    </div>
                                    <div class="col-md-6">
                                        <a href="javascript:void (0)"
                                            class="btn btn-default popup-btn resend_otp">Resend
                                            OTP</a>
                                    </div>

                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>

        </div>
    </section>
    <br clear="all" />


    <!--====== FOOTER PART START ======-->

    <footer class="pathAnimateActive">
        <div class="theme_top_bottom py-0">
            <div class="footer_top">

                <div class="container">

                    <div class="row rera-wrapper">
                        <div class="col-lg-6 rera-header">
                            <img src="assets/images/Maharera-Icon.webp" class="img-fluid">
                            <h2>MAHARERA DETAILS</h2>
                        </div>
                        <div class="col-lg-6 d-none d-md-block">
                            <p class="text-justify" style="color:#88442b;margin-top:10px;"><strong
                                    style="color:#000">Site Address:</strong>Chandak-Treesourus, Off Chincholi Bunder
                                Road, Malad West, Mumbai, Maharashtra 400064</p>
                        </div>
                        <div class="col-lg-12 rera-data">
                            <a href="https://maharera.mahaonline.gov.in/" target="_blank"
                                class="rera-web">https://maharera.mahaonline.gov.in/</a>
                            <p class="rera-detail">MahaRERA Registration No.: P51800048658</p>
                        </div>
                        <div class="col-lg-6 d-block d-md-none">
                            <p class="text-justify" style="color:#88442b;margin-top:10px;"><strong
                                    style="color:#000">Site Address:</strong> Chandak Treesourus, Off Chincholi Bunder
                                Road, Malad West, Mumbai, Maharashtra 400064</p>
                        </div>
                        <div class="col-lg-12 rera-disclaim">
                            <strong>PROJECT DISCLAIMER*</strong>
                            <p>Currently marketed as Codename Nostalgia. Project is registered on MahaRERA as Chandak
                                Treesourus bearing MahaRERA Registration No.P51800048658 and all the details in respect
                                of the Project are available on the website https://maharera.mahaonline.gov.in under
                                registered projects. The list of standard offerings, amenities and other details are
                                available for verification at site. Intending purchasers are requested to verify all the
                                details before acting in any manner with respect to the project.</p>
                        </div>
                    </div>


                    <div class="social-mob mob-view">
                        <h2><a href="https://www.chandakgroup.com/disclaimer">Follow Us on</a></h2>
                        <ul class="social">
                            <li><a href="https://www.instagram.com/chandakgroup/"><img
                                        src="assets/images/insta.webp"></a></li>
                            <li><a href="https://www.facebook.com/chandakgroup/"><img src="assets/images/fb.webp"></a>
                            </li>
                            <li><a href="https://www.youtube.com/channel/UCSB3HEWIFFeFi17o97IUaLA"><img
                                        src="assets/images/yt.webp"></a></li>
                            <!--                            <li><a href="https://in.linkedin.com/company/chandak-group"><img src="assets/images/linked.webp"></a></li>-->
                        </ul>

                    </div>

                    <div class="row sitemap-wrapper">
                        <div class="map-list">
                            <h2><a href="#overview" class="btm-page-scroll">Overview</a></h2>
                        </div>
                        <div class="map-list">
                            <h2><a href="#location" class="btm-page-scroll">Location</a></h2>
                        </div>

                        <div class="map-list">
                            <h2><a href="#config" class="btm-page-scroll">Configuration</a></h2>
                        </div>
                        <div class="map-list">
                            <h2><a href="#amenities" class="btm-page-scroll">Amenities</a></h2>
                        </div>

                        <div class="map-list">
                            <h2><a href="#highlights" class="btm-page-scroll">Project Highlights</a></h2>
                        </div>
                        <div class="map-list">
                            <h2><a href="#gallery" class="btm-page-scroll">Gallery</a></h2>
                        </div>
                        <div class="map-list">
                            <h2><a href="#about" class="btm-page-scroll">About Us</a></h2>
                        </div>

                    </div>


                </div>
            </div>
            <div class="footer_bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-4 tab1 tab2">
                            <div data-aos="fade-in" class="rightsResvered aos-init aos-animate">
                                <h2 class="mb-0">© All rights reserved</h2>
                            </div> <span class="line">&nbsp | &nbsp</span>
                            <div class="">
                                <h2 class="mb-0"><a href="https://www.chandakgroup.com/terms-and-conditions"
                                        class="">T&C</a></h2>
                            </div> <span class="line">&nbsp | &nbsp</span>
                            <div class="">
                                <h2 class="mb-0"><a href="https://www.chandakgroup.com/disclaimer">Disclaimer</a></h2>
                            </div>
                        </div>
                        <div class="map-list social-mob desk-view col-4">
                            <h2>Follow Us on</h2>
                            <ul class="social">
                                <li><a href="https://www.instagram.com/chandakgroup/"><img
                                            src="assets/images/insta.webp"></a></li>
                                <li><a href="https://www.facebook.com/chandakgroup/"><img
                                            src="assets/images/fb.webp"></a></li>
                                <li><a href="https://www.youtube.com/channel/UCSB3HEWIFFeFi17o97IUaLA"><img
                                            src="assets/images/yt.webp"></a></li>
                                <!--                            <li><a href="https://in.linkedin.com/company/chandak-group"><img src="assets/images/linked.webp"></a></li>-->
                            </ul>

                        </div>

                    </div>
                </div>
            </div>
        </div>

    </footer>

    <!--====== FOOTER PART ENDS ======-->


    <!-- Optional JavaScript -->
    <script src="js/jquery.min.js"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
    <script src="owlcarousel/owl.carousel.min.js"></script>
    <script src="js/jquery.validate.js"></script>
    <script src="js/mobilevalidate.js"></script>
    <script src="js/cookie.js"></script>
    <script src="js/popout.js"></script>
    <script src="js/parallax.min.js"></script>


    <script type="text/javascript">
    jQuery(document).ready(function($) {
        Delete_Cookie('formfilled');
    });
    </script>


    <script>
    function otpverify(elm) {

        jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', true);
        setTimeout(function() {
            jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', false);
        }, 5000);


        var Gfname = jQuery('#' + elm + ' input[name="fname"]').val();
        var Glname = jQuery('#' + elm + ' input[name="lname"]').val();


        var Gemail = jQuery('#' + elm + ' input[name="email"]').val();
        var Gmobile = jQuery('#' + elm + ' textarea[name="mobile"]').val();



        var otp = jQuery('#' + elm + ' input[name="otp"]').val();

        var getotp = Get_Cookie('projectscode');

        if (otp == "") {
            alert('Please Enter Otp');
            return false;
        }


        // if (elm == 'otp-form') {
        //     document.getElementById('broucher1').click();
        // }


        if (getotp == otp) {
            //alert('OTP Match');
            //$("#pageloader").fadeIn();
            // document.getElementById('broucher1').click();

            return true;


        } else {
            alert("Enter Correct OTP");
        }


        return false;
    }
    </script>


</body>

</html>