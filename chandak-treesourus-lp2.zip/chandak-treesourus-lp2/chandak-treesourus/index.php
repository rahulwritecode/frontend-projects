<?php
// $cstm_ppc_placement = $_REQUEST['cstm_ppc_placement'];
// $cstm_ppc_keyword = $_REQUEST['cstm_ppc_keyword'];
// $cstm_ppc_device = $_REQUEST['cstm_ppc_device'];
// $cstm_ppc_campaign = $_REQUEST['cstm_ppc_campaign'];
// $cstm_ppc_channel = $_REQUEST['cstm_ppc_channel'];

$cstm_media_type = $_REQUEST['cstm_media_type'];
$cstm_media_sub_type = $_REQUEST['cstm_media_sub_type'];
// $gclid = $_REQUEST['gclid'];

// if (isset($cstm_ppc_placement)) {
//     setcookie('cstm_ppc_placement', $cstm_ppc_placement, time() + (86400 * 180));
// }

// if (isset($cstm_ppc_keyword)) {
//     setcookie('cstm_ppc_keyword', $cstm_ppc_keyword, time() + (86400 * 180));
// }

// if (isset($cstm_ppc_device)) {
//     setcookie('cstm_ppc_device', $cstm_ppc_device, time() + (86400 * 180));
// }

// if (isset($cstm_ppc_campaign)) {
//     setcookie('cstm_ppc_campaign', $cstm_ppc_campaign, time() + (86400 * 180));
// }

// if (isset($cstm_ppc_channel)) {
//     setcookie('cstm_ppc_channel', $cstm_ppc_channel, time() + (86400 * 180));
// }
// if (isset($gclid)) {
//     setcookie('gclid', $gclid, time() + (86400 * 180));
// }

// cloudfront Distribution----     https://d18731pu9v4qwq.cloudfront.net
// PROD
// for production, keep below two lines uncommented, and comment below line labeled LOCAL
$assetVers = 3;
$assetBase = 'https://d18731pu9v4qwq.cloudfront.net/assets-' . $assetVers . '/';

// LOCAL
// for local, keep below line uncommented, and comment above two lines.
//  $assetBase = '';

?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <!-- Google Tag Manager -->
    <script>
    (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-WS9TJHC');
    </script>

    <!-- End Google Tag Manager -->
    <meta charset="utf-8">

    <!--====== Title ======-->
    <title>Chandak Treesourus | Largest-In-Class* 3BHK Sundeck Homes in Malad West a project by Chandak Group</title>

    <meta name="description"
        content="Presenting Chandak Treesourus! Largest-In-Class* 3BHK Sundeck Homes in Malad West with Duplex & Jodi Options, a project by Chandak Group. Near Chincholi Bunder, Malad Infinity Mall. Know More.">

    <meta name="keywords"
        content=" chandak malad, chandak malad west, chandak group, chandak project, chandak builder, 3 bhk in malad west, 3 bhk malad west, 3 bhk flats in malad west, chandak Treesourus">


    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="<?php echo $assetBase; ?>assets/images/favicon.webp" type="image/png">

    <!--====== Animate CSS ======-->
    <link rel="stylesheet" href="<?php echo $assetBase; ?>assets/css/animate.css">

    <!--====== Magnific Popup CSS ======-->
    <link rel="stylesheet" href="<?php echo $assetBase; ?>assets/css/magnific-popup.css">

    <!--====== Font Awesome CSS ======-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css" />

    <!--====== Bootstrap CSS ======-->
    <link rel="stylesheet" href="<?php echo $assetBase; ?>assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />

    <!--====== Default CSS ======-->
    <link rel="stylesheet" href="<?php echo $assetBase; ?>assets/css/default.css">

    <!--====== Style CSS ======-->
    <link rel="stylesheet" href="<?php echo $assetBase; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo $assetBase; ?>assets/css/responsive.css">

    <!-- Toastr CSS -->
    <link rel="stylesheet" href="<?php echo $assetBase; ?>assets/css/toastr.min.css">
    <link href="https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/assets/owl.carousel.min.css"
        rel="stylesheet">
    <link href="https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/assets/owl.theme.default.min.css"
        rel="stylesheet">


    <style>
    .video-play-button {
        position: absolute;
        z-index: 10;
        top: 50%;
        left: 50%;
        display: block;
        box-sizing: content-box;
        width: 2rem;
        height: 2.75rem;
        padding: 1.125rem 1.25rem 1.125rem 1.75rem;
        border-radius: 50%;
        -webkit-transform: translateX(-50%) translateY(-50%);
        -ms-transform: translateX(-50%) translateY(-50%);
        transform: translateX(-50%) translateY(-50%);
    }

    .video-play-button:before {
        content: "";
        position: absolute;
        z-index: 0;
        top: 50%;
        left: 50%;
        display: block;
        width: 3.75rem;
        height: 3.75rem;
        border-radius: 50%;
        background: #4eaaff;
        animation: pulse-border 1500ms ease-out infinite;
        -webkit-transform: translateX(-50%) translateY(-50%);
        -ms-transform: translateX(-50%) translateY(-50%);
        transform: translateX(-50%) translateY(-50%);
    }

    .video-play-button:after {
        content: "";
        position: absolute;
        z-index: 1;
        top: 50%;
        left: 50%;
        display: block;
        width: 3.375rem;
        height: 3.375rem;
        border-radius: 50%;
        background: #4eaaff;
        transition: all 200ms;
        -webkit-transform: translateX(-50%) translateY(-50%);
        -ms-transform: translateX(-50%) translateY(-50%);
        transform: translateX(-50%) translateY(-50%);
    }

    .video-play-button span {
        position: relative;
        display: block;
        z-index: 3;
        top: 0.375rem;
        left: 0.25rem;
        width: 0;
        height: 0;
        border-left: 1.625rem solid #fff;
        border-top: 1rem solid transparent;
        border-bottom: 1rem solid transparent;
    }

    @keyframes pulse-border {
        0% {
            transform: translateX(-50%) translateY(-50%) translateZ(0) scale(1);
            opacity: 1;
        }

        100% {
            transform: translateX(-50%) translateY(-50%) translateZ(0) scale(1.5);
            opacity: 0;
        }
    }
    </style>
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="50">

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WS9TJHC" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>

    <!-- End Google Tag Manager (noscript) -->
    <!--====== PRELOADER PART START ======-->

    <div class="preloader">
        <div class="loader">
            <div class="ytp-spinner">
                <div class="ytp-spinner-container">
                    <div class="ytp-spinner-rotator">
                        <div class="ytp-spinner-left">
                            <div class="ytp-spinner-circle"></div>
                        </div>
                        <div class="ytp-spinner-right">
                            <div class="ytp-spinner-circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--====== PRELOADER PART ENDS ======-->

    <!--====== HEADER PART START ======-->

    <header class="header-area">
        <div class="navbar-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg">
                            <a class="navbar-brand" href="index.php">
                                <img src="<?php echo $assetBase; ?>assets/images/logo.webp" class="logo-1" alt="Logo">
                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul class="navbar-nav m-auto">
                                    <li class="nav-item">
                                        <a class="page-scroll active" href="#overview">OVERVIEW</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="page-scroll " href="#highlights">Project Highlights</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="page-scroll " href="#location">LOCATION</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="page-scroll " href="#config">Configuration</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="page-scroll " href="#amenities">Amenities</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="page-scroll" href="#gallery">Gallery</a>
                                    </li>
                                    <!-- <li class="nav-item">
                                        <a class="page-scroll" href="#vids">Videos</a>
                                    </li> -->

                                    <li class="nav-item">
                                        <a class="page-scroll" href="#about">About Us</a>
                                    </li>

                                </ul>
                            </div> <!-- navbar collapse -->

                            <div class="navbar-btn d-sm-inline-block">
                                <a class="navbar-brand-2" href="index.php">
                                    <img src="<?php echo $assetBase; ?>assets/images/chandak-logo.webp" class="logo-2"
                                        alt="Logo">
                                    <!--                                    <img src="<?php echo $assetBase; ?>assets/images/logo-2.webp" class="logo-2" alt="Logo">-->
                                </a>
                            </div>
                        </nav> <!-- navbar -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- navbar area -->


    </header>

    <!--====== HEADER PART ENDS ======-->

    <div class="banner">
        <div class="banner-wrapper">
            <img src="<?php echo $assetBase; ?>assets/images/banner/web.jpg" class="desk-view img-fluid">
            <img src="<?php echo $assetBase; ?>assets/images/banner/mob.png" class="mob-view img-fluid">
        </div>
    </div>

    <div id="overview" class="overview section">
        <div class="container">
            <div class="section-head">
                <h1 class="text-center">OVERVIEW</h1>
            </div>
            <div class="row overview-wrapper">
                <div class="col-lg-6 overview-img">
                    <img src="<?php echo $assetBase; ?>assets/images/4.jpg" class="img-fluid d-none d-md-block">
                    <img src="<?php echo $assetBase; ?>assets/images/4.jpg" class="img-fluid d-block d-md-none">
                </div>
                <div class="col-lg-6 overview-txt">
                    <!-- <h2 class="text-center"><span class="line-1">A PLACE WHERE</span><br>
                        <span class="line-2">PURITY & FRESHNESS</span><br>
                        <span class="line-3">'COME TOGETHER'</span>
                    </h2> -->
                    <div class="flower">
                        <img src="<?php echo $assetBase; ?>assets/images/Divider.webp" alt="divider">
                    </div>
                    <p class="text-center">Chandak Treesourus is a premium residential development at Malad (W). We have
                        2 & 3 BHKs with duplexes and jodi options that come along with sun-decks. The project is a
                        modern development with a wide range of lifestyle amenities. The project has a lifetime of
                        unobstructed views to offer and is surrounded by 3+ acres of greens.</p>
                    <div class="flower">
                        <img src="<?php echo $assetBase; ?>assets/images/Divider.webp" alt="divider"
                            style="transform:rotate(180deg)">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="amenities section" id="highlights">
        <div class="container">
            <div class="section-head">
                <h1 class="text-center">PROJECT HIGHLIGHTS</h1>
            </div>
            <div class="row amenities-wrapper">

                <!-- <div class="col-lg-12 amenities-txt">
                    <h2 class="text-center"><span class="line-1">WHERE</span><br>
                        <span class="line-2">COMMUNITY, COMFORT & CALM</span><br>
                        <span class="line-3">'COME TOGETHER'</span>
                    </h2>
                </div> -->

                <div class="row amenities-img">
                    <div class="col-md-3 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/08.webp"
                                class="img-fluid"></div>
                        <p>45+ Storey Towers</p>
                    </div>
                    <div class="col-md-3 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/09.webp"
                                class="img-fluid"></div>
                        <p>Private Balconies</p>
                    </div>
                    <div class="col-md-3 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/02.webp"
                                class="img-fluid"></div>
                        <p>Spacious Homes</p>
                    </div>
                    <!-- <div class="col-md-4 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/view.webp" class="img-fluid"></div>
                        <p>Malad Mangroves And Creek View</p>
                    </div> -->
                    <div class="col-md-3 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/12.webp"
                                class="img-fluid"></div>
                        <p>Dedicated Amenity Floor</p>
                    </div>
                    <div class="col-md-3 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/10.webp"
                                class="img-fluid">
                        </div>
                        <p>Terrace And Podium Amenities</p>
                    </div>
                    <div class="col-md-3 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/07.webp"
                                class="img-fluid">
                        </div>
                        <p>20 + Lifestyle Amenities</p>
                    </div>
                    <div class="col-md-3 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/11.webp"
                                class="img-fluid">
                        </div>
                        <p>Great Connectivity</p>
                    </div>
                    <!-- <div class="col-md-4 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/design.webp" class="img-fluid"></div>
                        <p>Design Concept By International Firm</p>
                    </div> -->

                    <div class="col-md-3 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/01.webp"
                                class="img-fluid">
                        </div>
                        <p>Great Views</p>
                    </div>
                    <div class="col-md-3 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/03.webp"
                                class="img-fluid">
                        </div>
                        <p>Ample Greens</p>
                    </div>
                    <div class="col-md-3 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/04.webp"
                                class="img-fluid">
                        </div>
                        <p>Amazing Horizon Views</p>
                    </div>
                    <div class="col-md-3 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/05.webp"
                                class="img-fluid">
                        </div>
                        <p>Panaroma Of City Skyline Connectivity</p>
                    </div>
                    <div class="col-md-3 amenit-img">
                        <div class="amenit-box"><img src="<?php echo $assetBase; ?>assets/images/icons/06.webp"
                                class="img-fluid">
                        </div>
                        <p>Surrounded By Greens</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="location section" id="location">
        <div class="container">
            <div class="section-head">
                <h1 class="text-center">LOCATION</h1>
            </div>
            <div class="row location-wrapper">

                <div class="col-lg-6 location-txt">
                    <!-- <h2 class="text-center"><span class="line-1">WHERE</span><br>
                        <span class="line-2">PROXIMITY & CONVENIENCE</span><br>
                        <span class="line-3">'COME TOGETHER'</span>
                    </h2> -->
                    <div class="flower">
                        <img src="<?php echo $assetBase; ?>assets/images/Divider.webp" alt="divider">
                    </div>
                    <p class="text-center">Chandak Treesourus is located between the arterial roads of SV Road and Link
                        Road. This connects the project to all parts of the city with ease but at the same time keeps
                        you well buffered from the hustle and bustle.
                    </p>
                    <div class="flower">
                        <img src="<?php echo $assetBase; ?>assets/images/Divider.webp" alt="divider"
                            style="transform:rotate(180deg)">
                    </div>
                    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingOne">
                                <h4 class="panel-title">
                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"
                                        aria-expanded="true" aria-controls="collapseOne" class="collapsed">
                                        SCHOOLS
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel"
                                aria-labelledby="headingOne" aria-expanded="true">
                                <div class="panel-body">
                                    <ul>
                                        <li>Witty Intl <span>700 m</span></li>
                                        <li>Orchids Intl <span>1.9 km</span></li>
                                        <li>Ryan Intl <span> 2.7 km</span></li>
                                        <li>Oberoi Intl <span> 3.2 km</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingTwo">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion"
                                        href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        MALLS
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel"
                                aria-labelledby="headingTwo" aria-expanded="false" style="height: 0px;">
                                <div class="panel-body">
                                    <ul>
                                        <li>Infinity Mall<span>1.4 km</span></li>
                                        <li>Inorbit Mall <span>1.4 km</span></li>
                                        <li>Oberoi Mall <span>2.4 km</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingThree">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion"
                                        href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        HOSPITALS
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseThree" class="panel-collapse collapse" role="tabpanel"
                                aria-labelledby="headingThree" aria-expanded="false">
                                <div class="panel-body">
                                    <ul>
                                        <li>Vivanta Multispeciality<span>70 m</span></li>
                                        <li>Sun Multispeciality<span>1.3 km</span></li>
                                        <li>Lifeline Multispeciality<span>1.6 km</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingFive">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion"
                                        href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                        HOTELS
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseFive" class="panel-collapse collapse" role="tabpanel"
                                aria-labelledby="headingFive" aria-expanded="false">
                                <div class="panel-body">
                                    <ul>
                                        <li>Grand Hometel Sarovar<span>1 km</span></li>
                                        <li>Radisson<span>1 km</span></li>
                                        <li>The Westin<span>3.4 km</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingFour">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion"
                                        href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                        RECREATIONAL
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseFour" class="panel-collapse collapse" role="tabpanel"
                                aria-labelledby="headingFour" aria-expanded="false">
                                <div class="panel-body">
                                    <ul>
                                        <li>Mindspace Garden<span> 950 m</span></li>
                                        <li>Goregaon Sports Club<span>1.1 km</span></li>
                                        <li>Aarey Lake<span>4.3 km</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingSix">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion"
                                        href="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                        EASY ACCESSIBILITY
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseSix" class="panel-collapse collapse" role="tabpanel"
                                aria-labelledby="headingSix" aria-expanded="false">
                                <div class="panel-body">
                                    <ul>
                                        <li>S.V.Road<span>400 m</span></li>
                                        <li>New Link Road<span>650 m</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 location-img">
                    <img src="<?php echo $assetBase; ?>assets/images/map.webp" alt="">
                </div>

            </div>
        </div>
    </div>

    <div class="amenities section" id="config">
        <div class="container">
            <div class="section-head">
                <h1 class="text-center">PROJECT CONFIGURATION</h1>
            </div>
            <table class="table config-table">
                <thead>
                    <tr>
                        <th>Type</th>
                        <!-- <th>Rera Carpet Area</th> -->
                        <th>Floor Plan</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="background: #eee1d5;">
                        <td>1 BHK</td>
                        <!-- <td>Area</td> -->
                        <td>
                            <a href="javascript:void (0);" class="price-click twobhk"
                                onclick="setConfiguration('twobhk')">
                                Click Here
                            </a>
                        </td>
                    </tr>
                    <tr style="background:#fff;">
                        <td>2 BHK</td>
                        <!-- <td>Area</td> -->
                        <td>
                            <a href="javascript:void (0);" class="price-click threebhk"
                                onclick="setConfiguration('threebhk')">
                                Click Here
                            </a>
                        </td>
                    </tr>
                    <tr style="background:#eee1d5;">
                        <td> 3 BHK</td>
                        <!-- <td>Area</td> -->
                        <td>
                            <a href="javascript:void (0);" class="price-click jodione"
                                onclick="setConfiguration('jodione')">
                                Click Here
                            </a>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>

    <div class="location section" id="amenities">
        <div class="container">
            <div class="section-head">
                <h1 class="text-center">AMENITIES</h1>
            </div>
            <!-- <div class="tab-rwap">
                <ul class="nav nav-tabs mytab" role="tablist">
                    <li role="presentation" class="nav-item">
                        <a href="#extame" class="nav-link active" aria-controls="profile" role="tab" data-toggle="tab"
                            aria-expanded="true">Indoor Amenities
                        </a>
                    </li>
                    <li role="presentation" class="nav-item">
                        <a href="#intame" class="nav-link" aria-controls="settings" role="tab" data-toggle="tab"
                            aria-expanded="false">Podium Amenities
                        </a>
                    </li>
                    <li role="presentation" class="nav-item">
                        <a href="#terame" class="nav-link" aria-controls="settings" role="tab" data-toggle="tab"
                            aria-expanded="false">Terrace Floor Amenities
                        </a>
                    </li>
                </ul> -->
            <div class="tab-content">

                <div role="tabpanel" class="tab-pane fade-up active in d-none d-sm-block" id="extame">
                    <div class="tab-contenwrap row">
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/ame-icon/1.webp">
                                    <p>Gym</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/ame-icon/2.webp">
                                    <p>Café Zone</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/ame-icon/3.webp">
                                    <p>Yoga Lawn</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/ame-icon/4.webp">
                                    <p>Sky Lounge</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/ame-icon/5.webp">
                                    <p>Spa Zone</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/ame-icon/6.webp">
                                    <p>Mini Squash</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/ame-icon/7.webp">
                                    <p>Infinity Edge Pool</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/ame-icon/8.webp">
                                    <p>Private Dining</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/ame-icon/9.webp">
                                    <p>AV Room</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/ame-icon/10.webp">
                                    <p>Banquet Hall</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/ame-icon/11.webp">
                                    <p>Kids Play Area</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/ame-icon/12.webp">
                                    <p>Work From Terrace</p>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>


                <!-- Mobile -->

                <div role="tabpanel" class="tab-pane fade-up active in d-block d-sm-none" id="extame">
                    <div class="amenities-slider owl-carousel owl-theme ">

                        <!-- <div class="tab-contenwrap row"> -->
                        <div>
                            <div class="item">
                                <div class="amiwrap border-effect">
                                    <div class="bo">
                                        <img src="<?php echo $assetBase; ?>assets/images/ame-icon/1.webp">
                                        <p>Gym</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="amiwrap border-effect">
                                    <div class="bo">
                                        <img src="<?php echo $assetBase; ?>assets/images/ame-icon/2.webp">
                                        <p>Café Zone</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>

                            <div class="item">
                                <div class="amiwrap border-effect">
                                    <div class="bo">
                                        <img src="<?php echo $assetBase; ?>assets/images/ame-icon/3.webp">
                                        <p>Yoga Lawn</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="amiwrap border-effect">
                                    <div class="bo">
                                        <img src="<?php echo $assetBase; ?>assets/images/ame-icon/4.webp">
                                        <p>Sky Lounge</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>

                            <div class="item">
                                <div class="amiwrap border-effect">
                                    <div class="bo">
                                        <img src="<?php echo $assetBase; ?>assets/images/ame-icon/5.webp">
                                        <p>Spa Zone</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="amiwrap border-effect">
                                    <div class="bo">
                                        <img src="<?php echo $assetBase; ?>assets/images/ame-icon/6.webp">
                                        <p>Mini Squash</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>

                            <div class="item">
                                <div class="amiwrap border-effect">
                                    <div class="bo">
                                        <img src="<?php echo $assetBase; ?>assets/images/ame-icon/7.webp">
                                        <p>Infinity Edge Pool</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="amiwrap border-effect">
                                    <div class="bo">
                                        <img src="<?php echo $assetBase; ?>assets/images/ame-icon/8.webp">
                                        <p>Private Dining</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>

                            <div class="item">
                                <div class="amiwrap border-effect">
                                    <div class="bo">
                                        <img src="<?php echo $assetBase; ?>assets/images/ame-icon/9.webp">
                                        <p>AV Room</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="amiwrap border-effect">
                                    <div class="bo">
                                        <img src="<?php echo $assetBase; ?>assets/images/ame-icon/10.webp">
                                        <p>Banquet Hall</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>

                            <div class="item">
                                <div class="amiwrap border-effect">
                                    <div class="bo">
                                        <img src="<?php echo $assetBase; ?>assets/images/ame-icon/11.webp">
                                        <p>Kids Play Area</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="amiwrap border-effect">
                                    <div class="bo">
                                        <img src="<?php echo $assetBase; ?>assets/images/ame-icon/12.webp">
                                        <p>Work From Terrace</p>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <!-- </div> -->

                    </div>
                </div>

                <!-- <div role="tabpanel" class="tab-pane fade" id="intame">
                    <div class="tab-contenwrap row">
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/amenities/pool.webp">
                                    <p>Infinity Pool With Deck</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/amenities/sport.webp">
                                    <p>Multipurpose Lawn</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/amenities/playground.webp">
                                    <p>Kids Play Area</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/amenities/old-man.webp">
                                    <p>Senior Citizen Area</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->

                <!-- <div role="tabpanel" class="tab-pane fade" id="terame">
                    <div class="tab-contenwrap row">
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/amenities/party.webp">
                                    <p>Party Lawn</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/amenities/yoga.webp">
                                    <p>Yoga Lawn</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/amenities/top-deck.webp">
                                    <p>Sky Lounge</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/amenities/friend.webp">
                                    <p>Youth Corner</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/amenities/classroom.webp">
                                    <p>Kids Play Area, Hobby Creative Corner</p>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/amenities/old-man.webp">
                                    <p>Senior Citizen Area</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/amenities/dumbbell.webp">
                                    <p>Crossfit Area And Open Gym</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 col-xs-12">
                            <div class="amiwrap border-effect">
                                <div class="bo">
                                    <img src="<?php echo $assetBase; ?>assets/images/amenities/work.webp">
                                    <p>Work From Garden/Terrace</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
    </div>
    <!-- Temp Gallery -->
    <!-- 
    <div id="gallery" class="overview section">
        <div class="container">
            <div class="section-head">
                <h1 class="text-center">GALLERY</h1>
            </div>
            <div class="row overview-wrapper">
                <div class="col-lg-6 overview-img">
                    <img src="<?php echo $assetBase; ?>assets/images/Overview-Img.webp" class="img-fluid">
                </div>
                <div class="col-lg-12 overview-txt">
                    <h2 class="text-center"><span class="line-1">A PLACE WHERE</span><br>
                        <span class="line-2">PURITY & FRESHNESS</span><br>
                        <span class="line-3">'COME TOGETHER'</span>
                    </h2>
                    <div class="flower">
                        <img src="<?php echo $assetBase; ?>assets/images/Divider.webp" alt="divider">
                    </div>
                    <p class="text-center">Be a part of this enchanting world with spectacular views. Look out and see
                        the striking city skyline. Enjoy the horizon in the distance, as it gets painted with stunning
                        sunrises and sunsets. Escape to a world that reminds you of the good old days.
                        At Chandak Treesourus, everything you need, everything you want is here.
                    </p>
                    <div class="flower">
                        <img src="<?php echo $assetBase; ?>assets/images/Divider.webp" alt="divider" style="transform:rotate(180deg)">
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Temp Gallery -->


    <div class="gallery section" id="gallery">
        <div class="container">
            <div class="section-head">
                <h1 class="text-center">GALLERY</h1>
            </div>
            <div class="gall-wrap">
                <div class="amenities-slider owl-carousel owl-theme ">
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/3.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/3.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/4.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/4.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/14.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/14.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/2.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/2.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/6.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/6.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/7.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/7.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/5.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/5.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/8.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/8.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/9.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/9.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/10.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/10.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/11.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/11.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/12.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/12.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/13.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/13.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/14.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/14.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/15.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/15.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/16.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/16.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/17.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/17.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/18.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/18.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/19.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/19.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/20.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/20.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/21.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/21.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/22.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/22.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="amenities-gallery mg-mb">
                            <img src="<?php echo $assetBase; ?>assets/images/gallery/New/23.jpg">
                            <a data-fancybox="floorplan"
                                href="<?php echo $assetBase; ?>assets/images/gallery/New/23.jpg">
                                <div class="ami-overlay">
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ======= Videos ======= -->

    <section class="section light-grey" id="vids">
        <div class="container">
            <!-- <h2 class="sec-head head-center white">Videos</h2>
            <div class="head-line"></div> -->
            <div class="section-head">
                <h1 class="text-center">VIDEOS</h1>
            </div>



            <!-- Tab panes -->

            <!-- ======================================== -->
            <!-- <div class="amenities-slider owl-carousel owl-theme "> -->
            <div class="row">
                <div class="video-slider owl-carousel owl-theme ">
                    <div class="item">
                        <div class="video-click1">
                            <iframe width="100%" height="300"
                                src="https://www.youtube.com/embed/XIUI3sbDLec?si=FxMC7YeHEa1J0s6j"
                                title="YouTube video player" frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                allowfullscreen></iframe>
                        </div>
                    </div>
                    <div class="item">
                        <div class="video-click1">
                            <iframe width="100%" height="300"
                                src="https://www.youtube.com/embed/LFkTWns65Kk?si=usDRy0zjTvACEGEX"
                                title="YouTube video player" frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                allowfullscreen></iframe>
                        </div>
                    </div>

                    <div class="item">
                        <div class="video-click1">
                            <iframe width="100%" height="300"
                                src="https://www.youtube.com/embed/gZMQLNCZr4g?si=lbsmW6j1xVm8ynJM"
                                title="YouTube video player" frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                allowfullscreen></iframe>
                        </div>
                    </div>

                </div>
            </div>


            <!-- </div> -->

        </div>

        </div>
    </section>

    <!-- ======= Videos ======= -->


    <section id="about" class="feature-section section">
        <div class="container">
            <div class="section-head">
                <h1 class="text-center">ABOUT US</h1>
            </div>
            <div class="row justify-content-center">
                <div class="col-6 col-md-4">
                    <div class="single-feature">
                        <div class="icon">
                            <img src="<?php echo $assetBase; ?>assets/images/amenities/2.webp" class="img-fluid">
                        </div>
                        <div class="content">
                            <h3>35+</h3>
                            <p>
                                Years of Experience
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4">
                    <div class="single-feature">
                        <div class="icon">
                            <img src="<?php echo $assetBase; ?>assets/images/amenities/1.webp" class="img-fluid">
                        </div>
                        <div class="content">
                            <h3>8500+</h3>
                            <p>
                                Happy families
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4">
                    <div class="single-feature">
                        <div class="icon">
                            <img src="<?php echo $assetBase; ?>assets/images/amenities/3.webp" class="img-fluid">
                        </div>
                        <div class="content">
                            <h3>10 Million+ Sq. Ft.</h3>
                            <p>
                                Developed
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4">
                    <div class="single-feature">
                        <div class="icon">
                            <img src="<?php echo $assetBase; ?>assets/images/amenities/4.webp" class="img-fluid">
                        </div>
                        <div class="content">
                            <h3>30+</h3>
                            <p>
                                COMPLETED PROJECTS
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4">
                    <div class="single-feature">
                        <div class="icon">
                            <img src="<?php echo $assetBase; ?>assets/images/amenities/5.webp" class="img-fluid">
                        </div>
                        <div class="content">
                            <h3>Excellence</h3>
                            <p>
                                in Delivery
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4">
                    <div class="single-feature">
                        <div class="icon">
                            <img src="<?php echo $assetBase; ?>assets/images/amenities/6.webp" class="img-fluid">
                        </div>
                        <div class="content">
                            <h3>7</h3>
                            <p>
                                OC's in 1 Year
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!--====== FOOTER PART START ======-->

    <footer class="pathAnimateActive">
        <div class="theme_top_bottom py-0">
            <div class="footer_top">

                <div class="container">

                    <div class="row rera-wrapper">
                        <div class="col-lg-6">
                            <div class="col-lg-12 rera-header">
                                <img src="<?php echo $assetBase; ?>assets/images/Maharera-Icon.webp" class="img-fluid">
                                <h2>MAHARERA DETAILS</h2>
                            </div>

                            <div class="col-lg-12 rera-data">
                                <a href="https://maharera.mahaonline.gov.in/" target="_blank"
                                    class="rera-web">https://maharera.mahaonline.gov.in/</a>
                                <p class="rera-detail">MahaRERA Registration No.: P51800048658</p>
                            </div>
                        </div>

                        <div class="col-lg-6 text-center">
                            <img src="<?php echo $assetBase; ?>assets/images/qr.PNG" alt="QR Code" class="qr-img">
                        </div>
                        <div class="col-lg-12 d-none d-md-block">
                            <p class="text-justify" style="color:#3e5124;margin-top:10px;"><strong
                                    style="color:#000">Site Address:</strong> Chandak-Treesourus, Off Chincholi Bunder
                                Road, Malad West, Mumbai, Maharashtra 400064</p>
                        </div>
                        <div class="col-lg-6 d-block d-md-none">
                            <p class="text-justify" style="color:#88442b;margin-top:10px;"><strong
                                    style="color:#000">Site Address:</strong> Chandak Treesourus, Off Chincholi Bunder
                                Road, Malad West, Mumbai, Maharashtra 400064</p>
                        </div>
                        <div class="col-lg-12 rera-disclaim">
                            <strong>PROJECT DISCLAIMER*</strong>
                            <p><b>Chandak Treesourous MahaRERA Project Registration No. P51800048658</b> <a
                                    href=" https://maharera.mahaonline.gov.in" target="_blank">
                                    https://maharera.mahaonline.gov.in</a>This communication is purely conceptual and
                                not a legal offering. The information contained herein is only indicative in nature. All
                                the artworks, features, facilities, views, surroundings, landscape, amenities, images,
                                models, aesthetics, building height, elevation, furniture, fixtures, interior work,
                                design and/or any other details are artistic conceptualization for illustration purposes
                                only and do not purport to replicate the offering. The project design, amenities and
                                facilitates are subject to final approval by the concerned authority. Promoter will have
                                no control over the changing landscape in future. The list of standard offerings,
                                amenities and other details are available for verification at site and MahaRERA website.
                                Intending purchasers are requested to verify all the details before acting in any manner
                                with respect to the project. The project is financed by ICICI Bank Limited.</p>
                        </div>
                    </div>


                    <div class="social-mob mob-view">
                        <h2><a href="https://www.chandakgroup.com/disclaimer">Follow Us on</a></h2>
                        <ul class="social">
                            <li><a href="https://www.instagram.com/chandakgroup/"><img
                                        src="<?php echo $assetBase; ?>assets/images/insta.webp"></a></li>
                            <li><a href="https://www.facebook.com/chandakgroup/"><img
                                        src="<?php echo $assetBase; ?>assets/images/fb.webp"></a>
                            </li>
                            <li><a href="https://www.youtube.com/channel/UCSB3HEWIFFeFi17o97IUaLA"><img
                                        src="<?php echo $assetBase; ?>assets/images/yt.webp"></a></li>
                            <!--                            <li><a href="https://in.linkedin.com/company/chandak-group"><img src="<?php echo $assetBase; ?>assets/images/linked.webp"></a></li>-->
                        </ul>

                    </div>

                    <!-- <div class="row sitemap-wrapper">
                        <div class="map-list">
                            <h2><a href="#overview" class="btm-page-scroll">Overview</a></h2>
                        </div>
                        <div class="map-list">
                            <h2><a href="#location" class="btm-page-scroll">Location</a></h2>
                        </div>

                        <div class="map-list">
                            <h2><a href="#config" class="btm-page-scroll">Configuration</a></h2>
                        </div>
                        <div class="map-list">
                            <h2><a href="#amenities" class="btm-page-scroll">Amenities</a></h2>
                        </div>

                        <div class="map-list">
                            <h2><a href="#highlights" class="btm-page-scroll">Project Highlights</a></h2>
                        </div>
                        <div class="map-list">
                            <h2><a href="#about" class="btm-page-scroll">About Us</a></h2>
                        </div>

                    </div> -->


                </div>
            </div>
            <div class="footer_bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-4 tab1 tab2">
                            <div data-aos="fade-in" class="rightsResvered aos-init aos-animate">
                                <h2 class="mb-0">© All rights reserved</h2>
                            </div> <span class="line">&nbsp | &nbsp</span>
                            <div class="">
                                <h2 class="mb-0"><a href="https://www.chandakgroup.com/terms-and-conditions"
                                        class="">T&C</a></h2>
                            </div> <span class="line">&nbsp | &nbsp</span>
                            <div class="">
                                <h2 class="mb-0"><a href="https://www.chandakgroup.com/disclaimer">Disclaimer</a></h2>
                            </div>
                        </div>
                        <div class="map-list social-mob desk-view col-4">
                            <h2>Follow Us on</h2>
                            <ul class="social">
                                <li><a href="https://www.instagram.com/chandakgroup/"><img
                                            src="<?php echo $assetBase; ?>assets/images/insta.webp"></a></li>
                                <li><a href="https://www.facebook.com/chandakgroup/"><img
                                            src="<?php echo $assetBase; ?>assets/images/fb.webp"></a></li>
                                <li><a href="https://www.youtube.com/channel/UCSB3HEWIFFeFi17o97IUaLA"><img
                                            src="<?php echo $assetBase; ?>assets/images/yt.webp"></a></li>
                                <!--                            <li><a href="https://in.linkedin.com/company/chandak-group"><img src="<?php echo $assetBase; ?>assets/images/linked.webp"></a></li>-->
                            </ul>

                        </div>

                    </div>
                </div>
            </div>
        </div>

    </footer>

    <!--====== FOOTER PART ENDS ======-->
    <a id="layoutpdf1" style="display: none;"
        href="<?php echo $assetBase; ?>assets/images/Chandak_Treesourus_Brochure.pdf" download>
    </a>
    <a id="twobhk" style="display: none;" href="assets/CHANDAK_TREESOURUS_2BHK.pdf" download>
    </a>
    <a id="threebhk" style="display: none;" href="assets/CHANDAK_TREESOURUS_3BHKpdf" download>
    </a>
    <a id="jodione" style="display: none;" href="assets/CHANDAK_TREESOURUS_2+2.pdf" download>
    </a>
    <a id="joditwo" style="display: none;" href="assets/CHANDAK_TREESOURUS_3+2.pdf" download>
    </a>
    <a id="jodithree" style="display: none;" href="assets/CHANDAK_TREESOURUS_3+3.pdf" download>

    </a>
    <!-- <button class="btn btn-danger download1 btn-download hidden-xs">Download Brochure</button> -->

    <!--====== BACK TOP TOP PART START ======-->

    <a href="#" class="back-to-top"><i class=" fa fa-chevron-up"></i></a>
    <a id="floor" style="display: none;" href="" download></a>

    <!--====== BACK TOP TOP PART ENDS ======-->

    <div id="sidebar" class="sidebar-contact">
        <div class="enqure__now__btn h2 uppercase  toggle"><span>enquire now</span></div>
        <h2>ENQUIRE NOW</h2>
        <form id="float-form" action="thank-you.php" name="Enquiry-popup" method="POST" novalidate="novalidate"
            onsubmit="return save_landing_pageinfo('float-form');">
            <div class="row">
                <div class="form_input_ele col-12">
                    <input type="text" id="full_name" name="fname" data-parsley-errors-container="#full_name_error"
                        autocomplete="off" required="">
                    <input type="hidden" name="source" value="Enquiry form" id="source">
                    <span class="input_placeholder h2">Name*</span>
                </div>
                <div class="form_input_ele col-12 mobileNumberInput">
                    <input type="tel" id="mobile_number" name="mobile"
                        data-parsley-errors-container="#mobile_number_error" autocomplete="off" required=""
                        maxlength="10" onkeypress="return isNumberKey(event)">

                    <span class="input_placeholder h2">Mobile Number*</span>
                </div>
                <div class="form_input_ele col-12">
                    <input type="email" id="email" name="email" data-parsley-errors-container="#email_error"
                        autocomplete="off">
                    <span class="input_placeholder h2">Email Id</span>
                </div>
            </div>

            <div class="form-group col-md-12 pd">
                <div class="input-group" style="margin: 10px; padding: 0px 10px; display:block;">
                    <input type="checkbox" name="vehicle3" value="Boat" checked style="float: left; width:14px;">
                    <label for="vehicle3" style="display: block; font-size: 13px; margin-top: 14px;"> I agree to the
                        Chandak Group "T&C" <a href="https://www.chandakgroup.com/privacy-policy"
                            target="_blank">Privacy
                            Policy</a>
                    </label>
                </div>
            </div>



            <div class="col-12 text-center">
                <button class="btn btn-default " type="submit" id="frm_submitside" value="proceed">
                    Submit
                </button><br>
                <span style="color:white;" id="sidefrm_msg"></span>
            </div>

        </form>
    </div>
    <input type="hidden" id="hiddenOTPField" value="">

    <div id="popup-modal" class="modal fade popup-form" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">ENQUIRE NOW</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                </div>
                <div class="modal-body text-center">
                    <form id="pop-form" action="thank-you.php" name="pop-form" method="POST"
                        onsubmit="return save_landing_pageinfo('pop-form');">
                        <div class="row">
                            <div class="form_input_ele col-12">
                                <input type="text" id="fname" name="fname" autocomplete="off">
                                <input type="hidden" name="source" value="popup form" id="source">
                                <span class="input_placeholder h2">Name*</span>
                            </div>

                            <div class="form_input_ele col-12 mobileNumberInput">
                                <input type="tel" id="mobile_number3" name="mobile" autocomplete="off" maxlength="10"
                                    onkeypress="return isNumberKey(event)">

                                <span class="input_placeholder h2">Mobile Number*</span>
                            </div>
                            <div class="form_input_ele col-12">
                                <input type="email" id="email_id3" name="email" autocomplete="off">
                                <span class="input_placeholder h2">Email Id</span>
                            </div>

                            <div class="form-group col-md-12 pd">
                                <div class="input-group" style="margin: 10px; padding: 0px 10px; display:block;">
                                    <input type="checkbox" name="vehicle3" value="Boat" checked
                                        style="float: left; width:14px; margin-top: -4px;">
                                    <label for="vehicle3"
                                        style="display: block; font-size: 13px; margin-right:50px; margin-top: 14px;">
                                        I
                                        agree to the
                                        Chandak Group "T&C" <a href="https://www.chandakgroup.com/privacy-policy"
                                            target="_blank">Privacy
                                            Policy</a>
                                    </label>
                                </div>
                            </div>


                            <div class="clearfix"></div>
                            <div class="col-12 text-center">
                                <button class="btn btn-default " type="submit" id="frm_submitpopup" value="proceed">
                                    Submit
                                </button><br>
                                <span style="color:white;" id=""></span>
                            </div>
                        </div>





                    </form>
                </div>
            </div>

        </div>
    </div>

    <div id="price-popup" class="modal fade popup-form" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Floor Plan</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                </div>
                <div class="modal-body text-center">
                    <form id="price-pop" action="thank-you.php" name="price-pop" method="POST"
                        onsubmit="return save_landing_pageinfo('price-pop');">
                        <div class="row">
                            <div class="form_input_ele col-12">
                                <input type="text" id="fname" name="fname" autocomplete="off">
                                <input type="hidden" name="source" value="Floor form" id="source">
                                <input type="hidden" name="floorconf" value="">

                                <span class="input_placeholder h2">Name*</span>
                            </div>

                            <div class="form_input_ele col-12 mobileNumberInput">
                                <input type="tel" id="mobile_number3" name="mobile" autocomplete="off" maxlength="10"
                                    onkeypress="return isNumberKey(event)">

                                <span class="input_placeholder h2">Mobile Number*</span>
                            </div>
                            <div class="form_input_ele col-12">
                                <input type="email" id="email_id3" name="email" autocomplete="off">
                                <span class="input_placeholder h2">Email Id</span>
                            </div>
                            <div class="form_input_ele col-md-12 pd">
                                <div class="input-group" style="margin: 10px; padding: 0px 10px; display:block;">
                                    <input type="checkbox" name="vehicle3" value="Boat" checked
                                        style="float: left; width:14px;">
                                    <label for="vehicle3"
                                        style="display: inline-block; font-size: 13px; margin-right:50px; margin-top: 5px;">
                                        I
                                        agree to the
                                        Chandak Group "T&C" <a href="https://www.chandakgroup.com/privacy-policy"
                                            target="_blank">Privacy
                                            Policy</a>
                                    </label>
                                </div>
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-12 text-center">
                                <button class="btn btn-default " type="submit" id="frm_submitpopup" value="proceed">
                                    Submit
                                </button><br>
                                <span style="color:white;" id=""></span>
                            </div>
                        </div>





                    </form>
                </div>
            </div>

        </div>
    </div>

    <!-- Download Brochure -->
    <div id="download1" class="modal fade popup-form" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Download Brochure</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                </div>
                <div class="modal-body text-center">
                    <form id="download-brochure" action="thank-you.php" name="download-brochure" method="POST"
                        onsubmit="return save_landing_pageinfo('download-brochure');">
                        <div class="row">
                            <div class="form_input_ele col-12">
                                <input type="text" id="fname" name="fname" autocomplete="off">
                                <input type="hidden" name="source" value="Floor form" id="source">
                                <span class="input_placeholder h2">Name*</span>
                            </div>

                            <div class="form_input_ele col-12 mobileNumberInput">
                                <input type="tel" id="mobile_number3" name="mobile" autocomplete="off" maxlength="10"
                                    onkeypress="return isNumberKey(event)">

                                <span class="input_placeholder h2">Mobile Number*</span>
                            </div>
                            <div class="form_input_ele col-12">
                                <input type="email" id="email_id3" name="email" autocomplete="off">
                                <span class="input_placeholder h2">Email Id</span>
                            </div>
                            <div class="form_input_ele col-md-12 pd">
                                <div class="input-group" style="margin: 10px; padding: 0px 10px; display:block;">
                                    <input type="checkbox" name="vehicle3" value="Boat" checked
                                        style="float: left; width:14px;">
                                    <label for="vehicle3"
                                        style="display: inline-block; font-size: 13px; margin-right:50px; margin-top: 5px;">
                                        I
                                        agree to the
                                        Chandak Group "T&C" <a href="https://www.chandakgroup.com/privacy-policy"
                                            target="_blank">Privacy
                                            Policy</a>
                                    </label>
                                </div>
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-12 text-center">
                                <button class="btn btn-default " type="submit" id="frm_submitpopup" value="proceed">
                                    Submit
                                </button><br>
                                <span style="color:white;" id=""></span>
                            </div>
                        </div>





                    </form>
                </div>
            </div>

        </div>
    </div>
    <!-- Download Brochure -->
    <!-- 
    <div id="pageloader">
        <div class="loading-wrap">
            <img class="arrow-animated bounce1" src="<?php echo $assetBase; ?>assets/images/logo.webp">
        </div>
    </div> -->

    <!-- The Otp Modal -->

    <!--====== Jquery js ======-->
    <script src="<?php echo $assetBase; ?>assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="<?php echo $assetBase; ?>assets/js/vendor/modernizr-3.7.1.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="<?php echo $assetBase; ?>assets/js/popper.min.js"></script>
    <script src="<?php echo $assetBase; ?>assets/js/bootstrap.min.js"></script>

    <!--====== Plugins js ======-->
    <script src="<?php echo $assetBase; ?>assets/js/plugins.js"></script>

    <!--====== Slick js ======-->
    <script src="<?php echo $assetBase; ?>assets/js/slick.min.js"></script>

    <!--====== validate js ======-->
    <script src="<?php echo $assetBase; ?>assets/js/jquery.validate.js"></script>
    <script src="<?php echo $assetBase; ?>assets/js/mobilevalidate.js"></script>

    <!--====== Counter Up js ======-->
    <script src="<?php echo $assetBase; ?>assets/js/waypoints.min.js"></script>
    <script src="<?php echo $assetBase; ?>assets/js/jquery.counterup.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="<?php echo $assetBase; ?>assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Scrolling Nav js ======-->
    <script src="<?php echo $assetBase; ?>assets/js/jquery.easing.min.js"></script>
    <script src="<?php echo $assetBase; ?>assets/js/scrolling-nav.js"></script>

    <!--====== wow js ======-->
    <script src="<?php echo $assetBase; ?>assets/js/wow.min.js"></script>

    <!--====== Particles js ======-->
    <script src="<?php echo $assetBase; ?>assets/js/particles.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>

    <!--====== Main js ======-->
    <script src="<?php echo $assetBase; ?>assets/js/main.js"></script>
    <!--    <script src="<?php echo $assetBase; ?>assets/js/app.min.js"></script>-->

    <!-- Toastr JS -->
    <script src="<?php echo $assetBase; ?>assets/js/toastr.min.js"></script>
    <!-- cookies JS -->
    <script src="<?php echo $assetBase; ?>assets/js/cookie.js"></script>
    <script src="<?php echo $assetBase; ?>assets/js/url-tracking.js"></script>
    <script src="https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/owl.carousel.js"></script>

    <script>
    $(".toggle").click(function() {
        $(".sidebar-contact").toggleClass("active")
    });

    $('.carousel').slick({
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: true,
        dots: false,
        fade: true,
        autoplay: true,
        smartSpeed: 1200,
        prevArrow: "<img class='a-left control-c prev slick-prev' src='assets/images/arrow.webp'>",
        nextArrow: "<img class='a-right control-c next slick-next' src='assets/images/arrow.webp'>"
    });
    </script>

    <script type="text/javascript">
    function setConfiguration(confval) {
        $('#price-popup').modal('show');
        $("input[name=floorconf]").val(confval);
    }
    $(document).ready(function() {
        Delete_Cookie('formfilled');
        // ---------------for model only-----
        // $(".price-click").click(function() {
        //     $('#price-popup').modal('show');
        // });
        $(".download1").click(function() {
            $('#download1').modal('show');
        });



        // $(".twobhk").click(function() {
        //     $("#price-pop").modal("show");
        //     document.getElementById("source").value = "BHK 1";
        // });
        //   $(".threebhk").click(function () {
        //     $("#price-pop").modal("show");
        //     document.getElementById("source").value = "BHK 2";
        //   });
        //   $(".jodione").click(function () {
        //     $("#price-pop").modal("show");
        //     document.getElementById("source").value = "BHK 3";
        //   });
        //   $(".joditwo").click(function () {
        //     $("#price-pop").modal("show");
        //     document.getElementById("source").value = "BHK 4";
        //   });
        //   $(".jodithree").click(function () {
        //     $("#price-pop").modal("show");
        //     document.getElementById("source").value = "BHK 5";
        //   });

    });
    </script>

    <script>
    $(document).ready(function() {
        jQuery('.amenities-slider').owlCarousel({
            stagePadding: 0,
            loop: true,
            nav: true,
            margin: 40,
            autoplay: true,
            autoplayTimeout: 5000,
            autoplayHoverPause: false,
            dots: false,
            navText: ["<i class='fa fa-chevron-left'></i>", "<i class='fa fa-chevron-right'></i>"],
            items: 3,
            responsive: {
                0: {
                    items: 1
                },
                576: {
                    items: 2
                },
                1000: {
                    items: 3
                }
            }
        });

        setTimeout(function() {
            $('#popup-modal').modal('show');
        }, 10000);

        jQuery('.video-slider').owlCarousel({
            stagePadding: 0,
            loop: true,
            nav: true,
            margin: 40,
            autoplay: false,
            autoplayTimeout: 5000,
            autoplayHoverPause: false,
            dots: false,
            navText: ["<i class='fa fa-chevron-left'></i>", "<i class='fa fa-chevron-right'></i>"],
            items: 3,
            responsive: {
                0: {
                    items: 1
                },
                576: {
                    items: 2
                },
                1000: {
                    items: 2
                }
            }
        });
    });
    </script>
    <script>
    $('[data-fancybox="floorplan"]').fancybox({

        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: false,

        buttons: [
            //'slideShow',
            //'share',
            'zoom',
            'fullScreen',
            'close'
            //'download'
        ],
        thumbs: {
            autoStart: false
        }
    });
    </script>
    <script>
    $('input').focus(function() {
        $(this).parents('.form_input_ele').addClass('focused');
    });

    $('input').blur(function() {
        var inputValue = $(this).val();
        if (inputValue == "") {
            $(this).removeClass('filled');
            $(this).parents('.form_input_ele').removeClass('focused');
        } else {
            $(this).addClass('filled');
        }
    })

    $(":input[type='password']").keyup(function(event) {
        if ($(this).next('[type="password"]').length > 0) {
            $(this).next('[type="password"]')[0].focus();
        } else {
            if ($(this).parent().next().find('[type="password"]').length > 0) {
                $(this).parent().next().find('[type="password"]')[0].focus();
            }
        }
    });
    </script>

    <script>
    $(document).ready(function() {
        $('.your-class').slick({
            infinite: true,
            slidesToShow: 2,
            slidesToScroll: 2,
            arrows: true,
            prevArrow: "<img class='a-left control-c prev slick-prev' src='assets/images/arrow.webp'>",
            nextArrow: "<img class='a-right control-c next slick-next' src='assets/images/arrow.webp'>",
        });

        $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
            $('.your-class').slick('setPosition');
        });


    });
    </script>
    <script type="text/javascript">
    function save_landing_pageinfo(elm) {
        jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', true);
        setTimeout(function() {
            jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', false);
        }, 5000);
        var name = jQuery('#' + elm + ' input[name="fname"]').val();
        var mobileno = jQuery('#' + elm + ' input[name="mobile"]').val();
        var emailid = jQuery('#' + elm + ' input[name="email"]').val();
        var message = jQuery('#' + elm + ' textarea[name="message"]').val();
        var conf = jQuery('#' + elm + ' select[name="conf"]').val();
        var fsource = jQuery('#' + elm + ' input[name="source"]').val();
        var current_url = location.hostname;
        var floorconf = jQuery('#' + elm + ' input[name="floorconf"]').val();

        alert(floorconf);



        if (name == "") {
            //alert("Please Enter Your Name");
            return false;
        }

        if (conf == "") {
            //alert("Please Enter Your Name");
            return false;
        }

        mobileno = mobileno.replace(/[^0-9]/g, '');
        if (mobileno.length != 10) {
            //alert("Please Enter 10 Digit Mobile Number");
            return false;
        }

        // if (message == undefined) {
        //     message = "";
        // }

        if (floorconf == 'twobhk') {
            // $('.twobhk').click();
            document.getElementById('twobhk').click();
        } else if (floorconf == 'threebhk') {
            // $('#threebhk').click();
            document.getElementById('threebhk').click();

        } else if (floorconf == 'jodione') {
            // $('#jodione').click();
            document.getElementById('jodione').click();

        } else if (floorconf == 'joditwo') {
            // $('#joditwo').click();
            document.getElementById('joditwo').click();

        } else if (floorconf == 'jodithree') {
            // $('#jodithree').click();
            document.getElementById('jodithree').click();

        }
        if (elm == 'download-brochure') {
            document.getElementById('layoutpdf1').click();
        }

        var _phone = mobileno;

        if (name != "" && mobileno != "") {
            $("#pageloader").fadeIn();
            if (elm == 'download-brochure') {
                document.getElementById('layoutpdf1').click();
            }



            // if (elm == 'price-pop') {
            //     document.getElementById('floor').click();
            // }

            // makecallNormal(_phone);
            return true;
        }

        //Init CTC
        // Waybeo.CTC.Init({
        //     hash: '5dca7b62afab0'
        // });


        // function makecallNormal(_phone) {

        //     Waybeo.CTC.MakeCall({
        //         'hash': '5dca7b62afab0',
        //         'route_hash': '5dc93a2c8266e',
        //         'callerid_hash': '5dca7b62d419a',
        //         'contact_number': _phone
        //     }, eventCallBack);
        // }


        return false;
    }

    function submitForm(elm) {
        document.createElement('form').submit.call(document.getElementById(elm));
    }
    </script>
</body>

</html>