<?php
class PostData
{
    public function callback()
    {

        $channel = $_COOKIE['cstm_ppc_channel'];
        $campaign = $_COOKIE['cstm_ppc_campaign'];
        $placement = $_COOKIE['cstm_ppc_placement'];
        $keyword = $_COOKIE['cstm_ppc_keyword'];

        $fname = $_REQUEST['fname'];
        $lname = $_REQUEST['lname'];
        $email = $_REQUEST['email'];
        $mobile = str_replace(' ', '', $_REQUEST['mobile']);
        $projectname = $_REQUEST['projectname'];
        $source = $_REQUEST['source'];
        $message = $_REQUEST['message'];
        //$country_code = $_REQUEST['country_code'];
        $name = $fname . ' ' . $lname;

        
        $fullmobile = "91" . $mobile;



        // Google Sheet Interation------------------

        $enqproject = '';

        $postFields = "entry.449648499=" . $name;
        $postFields .= "&entry.1379833540=" . $email;
        $postFields .= "&entry.758332158=" . $fullmobile;
        $postFields .= "&entry.1900106466=" . $message;
        $postFields .= "&entry.1693361781=" . $source;
        $postFields .= "&entry.1264955311=" . $enqproject;

        $postFields .= '&entry.1830911442=' . urlencode($_COOKIE['cstm_ppc_campaign']);
        $postFields .= '&entry.939490048=' . urlencode($_COOKIE['cstm_ppc_channel']);
        $postFields .= '&entry.729166844=' . urlencode($_COOKIE['cstm_ppc_keyword']);
        $postFields .= '&entry.839903606=' . urlencode($_COOKIE['cstm_ppc_placement']);
        $postFields .= '&entry.2003337495=' . urlencode($_COOKIE['cstm_ppc_device']);

        $ch3 = curl_init();
        curl_setopt($ch3, CURLOPT_URL, "https://docs.google.com/forms/u/1/d/e/1FAIpQLSdBVE5atujAhIddK1urvAA7Moq7BeSsiLI3-eWtkild8oz7Qg/formResponse");
        curl_setopt($ch3, CURLOPT_POST, 1);
        curl_setopt($ch3, CURLOPT_POSTFIELDS, $postFields);
        curl_setopt($ch3, CURLOPT_HEADER, 0);
        curl_setopt($ch3, CURLOPT_RETURNTRANSFER, true);
        $result3 = curl_exec($ch3);
        
        // Integration
        
        $jayParsedAry = [
            "name" => $fname, 
            "rep_cms_email" => $email, 
            "rep_cms_mobile" => $mobile, 
            "channel" => $channel, 
            "campaign" => $campaign, 
            "keyword" => $keyword, 
            "placement" => $placement, 
            "device" => "M", 
            "developer_id" => "company_ec0338d3", 
            "project_id" => "project_6cca490a",
            "otp_verified" => true
            
         ]; 
          

         $jsonpardata = json_encode($jayParsedAry, true);
        //  var_dump($jsonpardata);
      
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://orca.realatte.com/api/web-to-lead',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>$jsonpardata,
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        // echo $response;
        // die;

        // do not delete
        return true;
    }

}



?>