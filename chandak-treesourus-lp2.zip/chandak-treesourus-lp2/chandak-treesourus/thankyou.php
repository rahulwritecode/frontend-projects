<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

$name = $_REQUEST['fname'];
$mobile = $_REQUEST['mobile'];
$email = $_REQUEST['email'];

$request = $_SERVER['REQUEST_METHOD'];

if ($request !== 'POST') {
    http_response_code(405);
    echo 'Method Not Allowed';
    echo '</br>';
    echo "<a href='index.php'>Go Back</a>";
    die;
}

if ($_REQUEST['mobile'] == '') {
    echo 'Please enter valid mobile number';
    echo '</br>';
    echo "<a href='index.php'>Go Back</a>";
    die;
}

if (strlen($_REQUEST['mobile']) !== 10) {
    echo 'Please enter valid mobile number';
    echo '</br>';
    echo "<a href='index.php'>Go Back</a>";
    die;
}



require_once 'send_leads.php';

$postData = new PostData();

if ((!isset($_COOKIE['formfilled'])) && isset($_REQUEST['mobile'])) {

    $mailsent = $postData->callback();
    setcookie('formfilled', 'yes');
} else {
    $mailsent = false;
}


?>
<!DOCTYPE html>
<html>

<head>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WS9TJHC');</script>

<!-- End Google Tag Manager -->
    <meta charset="utf-8">

    <!--====== Title ======-->
    <title>Thank You | Chandak Treesourus | Largest-In-Class* 3BHK Sundeck Homes in Malad West a project by Chandak Group</title>

    <meta name="description"
        content="Presenting Chandak Treesourus! Largest-In-Class* 3BHK Sundeck Homes in Malad West with Duplex & Jodi Options, a project by Chandak Group. Near Chincholi Bunder, Malad Infinity Mall. Know More.">

    <meta name="keywords" content="chandak malad, chandak malad west, chandak group, chandak project, chandak builder, 3 bhk in malad west, 3 bhk malad west, 3 bhk flats in malad west, chandak Treesourus
">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.webp" type="image/png">

    <!--====== Animate CSS ======-->
    <link rel="stylesheet" href="assets/css/animate.css">

    <!--====== Magnific Popup CSS ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!--====== Slick CSS ======-->
    <link rel="stylesheet" href="assets/css/slick.css">

    <!--====== Line Icons CSS ======-->
    <link rel="stylesheet" href="assets/css/LineIcons.css">

    <!--====== Font Awesome CSS ======-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!--====== Bootstrap CSS ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lity/2.4.1/lity.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.css" />

    <!--====== Default CSS ======-->
    <link rel="stylesheet" href="assets/css/default.css">

    <!--====== Style CSS ======-->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">

    <!-- Toastr CSS -->
    <link rel="stylesheet" href="assets/css/toastr.min.css">
</head>

<body>

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WS9TJHC"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <!--====== HEADER PART START ======-->

    <header class="header-area">
        <div class="navbar-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg">
                            <a class="navbar-brand" href="index.php">
                                <img src="assets/images/logo.webp" class="logo-1" alt="Logo">
                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul class="navbar-nav m-auto">
                                    <li class="nav-item">
                                        <a class="page-scroll active" href="#overview">OVERVIEW</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="page-scroll " href="#location">LOCATION</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="page-scroll " href="#config">CONFIGURATIONS</a>
                                    </li>

                                    <!-- <li class="nav-item">
                                        <a class="page-scroll " href="#amenities">Amenities</a>
                                    </li> -->

                                    <li class="nav-item">
                                        <a class="page-scroll " href="#highlights">PROJECT HIGHLIGHTS</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="page-scroll " href="#gallery">GALLERY</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="page-scroll" href="#about">SHOW FLAT</a>
                                    </li>

                                </ul>
                            </div> <!-- navbar collapse -->

                            <div class="navbar-btn d-sm-inline-block">
                                <a class="navbar-brand-2" href="index.php">
                                    <img src="assets/images/chandak-logo.webp" class="logo-2" alt="Logo">
                                    <!--                                    <img src="assets/images/logo-2.webp" class="logo-2" alt="Logo">-->
                                </a>
                            </div>
                        </nav> <!-- navbar -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- navbar area -->


    </header>

    <!--====== HEADER PART ENDS ======-->


    <section class="glob-sec thank-sec">
        <div class="container">
            <span class="msgicon" aria-hidden="true"><i class="fa fa-check" aria-hidden="true"></i></span>
            <h2 class="oops">You're all set!</h2>
            <h3 class="oops-greet" style="text-align:center;">Greetings From Chandak Treesourus,</h3>
            <h3 class="oops-subtitle" style="text-align:center;">
                Thank you for expressing interest on our website.<br />
                Our expert will get in touch with you shortly.
            </h3>
            <div class="text-center">
                <a href="index.php" style="text-decoration: none;">
                    <h2 class="go-home"><span class="" aria-hidden="true"><i class="fa fa-arrow-left"
                                aria-hidden="true"></i></span> GO
                        BACK TO HOME</h2>
                </a>
            </div>
        </div>
    </section>

    <!--====== FOOTER PART START ======-->

    <footer class="pathAnimateActive">
        <div class="theme_top_bottom py-0">
            <div class="footer_top">

                <div class="container">

                    <div class="row rera-wrapper">
                        <div class="col-lg-6 rera-header">
                            <img src="assets/images/Maharera-Icon.webp" class="img-fluid">
                            <h2>MAHARERA DETAILS</h2>
                        </div>
                        <div class="col-lg-6 d-none d-md-block">
                            <p class="text-justify" style="color:#88442b;margin-top:10px;"><strong
                                    style="color:#000">Site Address:</strong> Chandak Treesourus, Off Chincholi Bunder
                                Road, Malad West, Mumbai, Maharashtra 400064</p>
                        </div>
                        <div class="col-lg-12 rera-data">
                            <a href="https://maharera.mahaonline.gov.in/" target="_blank"
                                class="rera-web">https://maharera.mahaonline.gov.in/</a>
                            <p class="rera-detail">MahaRERA Registration No.: P51800048658</p>
                        </div>
                        <div class="col-lg-6 d-block d-md-none">
                            <p class="text-justify" style="color:#88442b;margin-top:10px;"><strong
                                    style="color:#000">Site Address:</strong> Chandak Treesourus, Off Chincholi Bunder
                                Road, Malad West, Mumbai, Maharashtra 400064</p>
                        </div>
                        <div class="col-lg-12 rera-disclaim">
                            <strong>PROJECT DISCLAIMER*</strong>
                            <p>Currently marketed as Chandak Treesourus. Project is registered on MahaRERA as Chandak
                                Treesourus bearing MahaRERA Registration No.P51800048658 and all the details in respect
                                of the Project are available on the website https://maharera.mahaonline.gov.in under
                                registered projects. The list of standard offerings, amenities and other details are
                                available for verification at site. Intending purchasers are requested to verify all the
                                details before acting in any manner with respect to the project.</p>
                        </div>
                    </div>


                    <div class="social-mob mob-view">
                        <h2><a href="https://www.chandakgroup.com/disclaimer">Follow Us on</a></h2>
                        <ul class="social">
                            <li><a href="https://www.instagram.com/chandakgroup/"><img
                                        src="assets/images/insta.webp"></a></li>
                            <li><a href="https://www.facebook.com/chandakgroup/"><img src="assets/images/fb.webp"></a>
                            </li>
                            <li><a href="https://www.youtube.com/channel/UCSB3HEWIFFeFi17o97IUaLA"><img
                                        src="assets/images/yt.webp"></a></li>
                            <!--                            <li><a href="https://in.linkedin.com/company/chandak-group"><img src="assets/images/linked.webp"></a></li>-->
                        </ul>

                    </div>

                    <div class="row sitemap-wrapper">
                        <div class="map-list">
                            <h2><a href="#overview" class="btm-page-scroll">Overview</a></h2>
                        </div>
                        <div class="map-list">
                            <h2><a href="#location" class="btm-page-scroll">Location</a></h2>
                        </div>

                        <div class="map-list">
                            <h2><a href="#config" class="btm-page-scroll">Configuration</a></h2>
                        </div>
                        <div class="map-list">
                            <h2><a href="#amenities" class="btm-page-scroll">Amenities</a></h2>
                        </div>

                        <div class="map-list">
                            <h2><a href="#highlights" class="btm-page-scroll">Project Highlights</a></h2>
                        </div>
                        <div class="map-list">
                            <h2><a href="#gallery" class="btm-page-scroll">Gallery</a></h2>
                        </div>
                        <div class="map-list">
                            <h2><a href="#about" class="btm-page-scroll">About Us</a></h2>
                        </div>

                    </div>


                </div>
            </div>
            <div class="footer_bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-4 tab1 tab2">
                            <div data-aos="fade-in" class="rightsResvered aos-init aos-animate">
                                <h2 class="mb-0">© All rights reserved</h2>
                            </div> <span class="line">&nbsp | &nbsp</span>
                            <div class="">
                                <h2 class="mb-0"><a href="https://www.chandakgroup.com/terms-and-conditions"
                                        class="">T&C</a></h2>
                            </div> <span class="line">&nbsp | &nbsp</span>
                            <div class="">
                                <h2 class="mb-0"><a href="https://www.chandakgroup.com/disclaimer">Disclaimer</a></h2>
                            </div>
                        </div>
                        <div class="map-list social-mob desk-view col-4">
                            <h2>Follow Us on</h2>
                            <ul class="social">
                                <li><a href="https://www.instagram.com/chandakgroup/"><img
                                            src="assets/images/insta.webp"></a></li>
                                <li><a href="https://www.facebook.com/chandakgroup/"><img
                                            src="assets/images/fb.webp"></a></li>
                                <li><a href="https://www.youtube.com/channel/UCSB3HEWIFFeFi17o97IUaLA"><img
                                            src="assets/images/yt.webp"></a></li>
                                <!--                            <li><a href="https://in.linkedin.com/company/chandak-group"><img src="assets/images/linked.webp"></a></li>-->
                            </ul>

                        </div>

                    </div>
                </div>
            </div>
        </div>

    </footer>

    <!--====== FOOTER PART ENDS ======-->


    <script src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="lightbox/light-box.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/wow.js"></script>

    <script>
    jQuery(document).ready(function($) {
        // Add smooth scrolling to all links
        $(".m-link").on('click', function(event) {

            // Make sure this.hash has a value before overriding default behavior
            if (this.hash !== "") {
                // Prevent default anchor click behavior
                event.preventDefault();

                // Store hash
                var hash = this.hash;

                // Using jQuery's animate() method to add smooth page scroll
                // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area

                $('html, body').animate({
                    scrollTop: $(hash).offset().top
                }, 800, function() {
                    // Add hash (#) to URL when done scrolling (default click behavior)
                    // window.location.hash = hash;
                });
            } // End if
        });

        $('.navbar-nav li').on('click', function() {
            $('.navbar-nav li.active').removeClass('active');
            $(this).addClass('active');
        });
        $(document).on('click', '.navbar-collapse.in', function(e) {
            if ($(e.target).is('a') && ($(e.target).attr('class') != 'dropdown-toggle')) {
                $(this).collapse('hide');
            }
        });
    });
    </script>

</body>

</html>